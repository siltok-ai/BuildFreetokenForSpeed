__version__ = "0.1.3+speed.qwen1"
