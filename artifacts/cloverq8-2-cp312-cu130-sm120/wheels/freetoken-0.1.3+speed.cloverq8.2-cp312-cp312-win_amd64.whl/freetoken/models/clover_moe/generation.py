# SPDX-License-Identifier: Apache-2.0
# Copyright 2025 The Qwen Team and The HuggingFace Inc. team. All rights reserved.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at http://www.apache.org/licenses/LICENSE-2.0
# Unless required by applicable law or agreed to in writing, software distributed
# under the License is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR
# CONDITIONS OF ANY KIND. See the License for the specific language governing
# permissions and limitations under the License.
# Source: DiffuSpace/Clover-35B-A3B-Preview@4b0402b65e523d0183a14c431955438714cb16ff
# Paths: sampling_clover_moe.py; modeling_clover_moe.py (generate control flow)
# Local changes: native LowConfidence loop; bitwise-equivalent dense repetition
# on small CUDA rows avoids boolean-index synchronization. Reference operation
# order, length/thinking biases and confidence functions are retained.
"""Response-only penalties for Clover block LowConfidence generation.

Presence, frequency and repetition use committed response history.
Length and thinking controls provide gradual stopping biases.
All state belongs to one generate request; prompt tokens are never accumulated.
"""

import math
import json
from pathlib import Path

import torch


PENALTY_DEFAULTS = {
    "presence_penalty": 0.0,
    "frequency_penalty": 0.0,
    "repetition_penalty": 1.0,
    "dllm_length_penalty": 0.0,
    "dllm_length_penalty_start": 8192,
    "dllm_length_penalty_window": 8192,
    "dllm_think_end_bias": 0.0,
    "dllm_think_end_start": 4096,
    "dllm_think_end_window": 4096,
    "dllm_think_end_token_id": None,
    "stop_token_ids": [],
}


def load_generation_settings(model_path, hf_config):
    metadata = getattr(hf_config, "metadata", None)
    if metadata is None:
        path = Path(model_path) / "generation_config.json"
        raw = json.loads(path.read_text(encoding="utf-8")) if path.exists() else {}
        return int(hf_config.mask_token_id), raw
    # The release GGUF omits length/thinking and presence controls. Preserve
    # Clover's published preset; explicitly encoded sampling metadata takes priority.
    tokens = metadata.get("tokenizer.ggml.tokens", [])
    if "</think>" not in tokens:
        raise ValueError("Clover GGUF tokenizer is missing </think>")
    raw = dict(
        do_sample=False,
        temperature=metadata.get("general.sampling.temp", 1.0),
        top_p=metadata.get("general.sampling.top_p", 1.0),
        top_k=None,
        presence_penalty=metadata.get("general.sampling.penalty_present", 0.9),
        frequency_penalty=metadata.get("general.sampling.penalty_freq", 0.0),
        repetition_penalty=metadata.get("general.sampling.penalty_repeat", 1.05),
        dllm_length_penalty=10.0,
        dllm_length_penalty_start=8192,
        dllm_length_penalty_window=8192,
        dllm_think_end_bias=10.0,
        dllm_think_end_start=4096,
        dllm_think_end_window=4096,
        dllm_think_end_token_id=tokens.index("</think>"),
        eos_token_id=list(
            dict.fromkeys(
                (
                    metadata["tokenizer.ggml.eos_token_id"],
                    metadata["tokenizer.ggml.padding_token_id"],
                )
            )
        ),
        pad_token_id=metadata["tokenizer.ggml.padding_token_id"],
    )
    return int(metadata["tokenizer.ggml.mask_token_id"]), raw


def validate_penalties(gen, vocab_size):
    for name, default in PENALTY_DEFAULTS.items():
        if getattr(gen, name, None) is None:
            setattr(gen, name, default)
    for name in ("presence_penalty", "frequency_penalty"):
        value = getattr(gen, name)
        if not math.isfinite(value) or not -2 <= value <= 2:
            raise ValueError(f"{name} must be finite and in [-2, 2]")
    if not math.isfinite(gen.repetition_penalty) or not 0 < gen.repetition_penalty <= 2:
        raise ValueError("repetition_penalty must be finite and in (0, 2]")
    for prefix, strength in (
        ("dllm_length_penalty", "dllm_length_penalty"),
        ("dllm_think_end", "dllm_think_end_bias"),
    ):
        value = getattr(gen, strength)
        if not math.isfinite(value) or value < 0:
            raise ValueError(f"{strength} must be finite and nonnegative")
        for suffix, minimum in (("start", 0), ("window", 1)):
            name = f"{prefix}_{suffix}"
            value = getattr(gen, name)
            if not isinstance(value, int) or isinstance(value, bool) or value < minimum:
                raise ValueError(f"{name} must be an integer >= {minimum}")
    close = gen.dllm_think_end_token_id
    if close is not None and (
        not isinstance(close, int) or not 0 <= close < vocab_size
    ):
        raise ValueError("dllm_think_end_token_id must be a valid token ID")
    if gen.dllm_think_end_bias and close is None:
        raise ValueError("dllm_think_end_bias requires dllm_think_end_token_id")
    if not isinstance(gen.stop_token_ids, (list, tuple)) or any(
        not isinstance(i, int) or not 0 <= i < vocab_size for i in gen.stop_token_ids
    ):
        raise ValueError("stop_token_ids must be a list of valid token IDs")


class CloverPenaltyState:
    def __init__(self, gen, vocab_size, device, stop_ids):
        self.gen = gen
        self.length = 0
        self.active = bool(
            gen.presence_penalty
            or gen.frequency_penalty
            or gen.repetition_penalty != 1
            or gen.dllm_length_penalty
            or gen.dllm_think_end_bias
        )
        self.counts = (
            torch.zeros(vocab_size, dtype=torch.int64, device=device)
            if self.active
            else None
        )
        self.stop_ids = sorted({i for i in stop_ids if 0 <= i < vocab_size})

    def commit(self, tokens):
        """Count each returned response token once, after full block resolution."""
        self.length += tokens.numel()
        if self.active:
            self.counts.index_add_(
                0, tokens, torch.ones_like(tokens, dtype=self.counts.dtype)
            )

    def apply(self, logits, block, mask_id):
        """Mutate fresh [block, vocab] logits before sampling and confidence."""
        if not self.active:
            return logits
        gen = self.gen
        # Uncommitted block tokens must not penalize themselves or other slots.
        # This snapshot changes only when the returned block is committed.
        seen = self.counts > 0
        # Keep SGLang's additive operation order and FP32 rounding boundaries.
        if gen.frequency_penalty:
            logits.sub_(self.counts.float() * gen.frequency_penalty)
        if gen.presence_penalty:
            logits.sub_(seen * gen.presence_penalty)
        if gen.repetition_penalty != 1:
            if (
                logits.is_cuda
                and logits.dtype == torch.float32
                and logits.shape[0] <= 16
            ):
                # Boolean indexing synchronizes to size its nonzero result.
                # Full-row arithmetic keeps the same scalar operations on GPU.
                scaled = torch.where(
                    logits < 0,
                    logits * gen.repetition_penalty,
                    logits / gen.repetition_penalty,
                )
                logits.copy_(torch.where(seen[None, :], scaled, logits))
            else:
                values = logits[:, seen]
                logits[:, seen] = torch.where(
                    values < 0,
                    values * gen.repetition_penalty,
                    values / gen.repetition_penalty,
                )
        positions = self.length + torch.arange(
            1, logits.shape[0] + 1, device=logits.device
        )

        def ramp(start, window, strength):
            return ((positions.float() - start) / window).clamp(0, 1) * strength

        if gen.dllm_length_penalty and self.stop_ids:
            logits[:, self.stop_ids] += ramp(
                gen.dllm_length_penalty_start,
                gen.dllm_length_penalty_window,
                gen.dllm_length_penalty,
            )[:, None]
        if gen.dllm_think_end_bias:
            close = gen.dllm_think_end_token_id
            # In LowConfidence the whole block receives the bias until a close
            # token is visible or committed.
            visible_close = ((block != mask_id) & (block == close)).any()
            enabled = ~(seen[close] | visible_close)
            logits[:, close] += enabled * ramp(
                gen.dllm_think_end_start,
                gen.dllm_think_end_window,
                gen.dllm_think_end_bias,
            )
        return logits


def resolve_low_confidence(preview, state, *, width, mask_id, threshold, device):
    """Official full-width loop, including the final partial returned block.

    `preview` must be read-only. Only the caller may commit the resolved prefix.
    Confidence and selection remain on device; the small step trace is evidence.
    """
    if torch.device(device).type != "cuda" or state.gen.do_sample:
        raise ValueError("Clover serving LowConfidence requires CUDA and greedy generation")
    block = torch.full((width,), mask_id, device=device, dtype=torch.int32)
    pending = torch.ones(width, device=device, dtype=torch.bool)
    steps = []
    from freetoken.kernel.triton.clover_pick import pick_with_confidence, resolve_step

    result = torch.empty(2, device=device, dtype=torch.int32)
    for _ in range(width):
        logits = preview(block)
        prediction, confidence = pick_with_confidence(logits, state, block, mask_id)
        resolve_step(block, pending, prediction, confidence, threshold, result)
        count, remaining = result.cpu().tolist()
        steps.append(count)
        if remaining == 0:
            return block, steps
    raise RuntimeError("LowConfidence failed to resolve its full block")
