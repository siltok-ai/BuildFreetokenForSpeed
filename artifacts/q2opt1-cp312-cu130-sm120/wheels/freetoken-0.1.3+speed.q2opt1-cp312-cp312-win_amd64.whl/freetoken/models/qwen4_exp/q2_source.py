"""Expert-only GGUF v3 source; deliberately independent of GGUF trunk/PLE readers."""
from __future__ import annotations

import math
from pathlib import Path
import re
import struct

import torch

SOURCE_SHA256 = "69820c02ec7d0b45ef2ebb19d6620299db749fe2aded7f39f93c6b88b199b720"
SOURCE_SIZE = 37_623_740_192
_FORMATS = {0: "B", 1: "b", 2: "H", 3: "h", 4: "I", 5: "i", 6: "f", 7: "?", 10: "Q", 11: "q", 12: "d"}


def _read(stream, count):
    data = stream.read(count)
    if len(data) != count:
        raise ValueError("truncated GGUF expert source")
    return data


def _unpack(stream, fmt):
    return struct.unpack("<" + fmt, _read(stream, struct.calcsize("<" + fmt)))


def _string(stream):
    size, = _unpack(stream, "Q")
    if size > 16 << 20:
        raise ValueError("oversized GGUF string")
    return _read(stream, size).decode("utf-8")


def _value(stream, kind=None, *, keep=True):
    if kind is None:
        kind, = _unpack(stream, "I")
    if kind == 8:
        return _string(stream)
    if kind == 9:
        elem, count = _unpack(stream, "IQ")
        if count > 10_000_000:
            raise ValueError("oversized GGUF metadata array")
        if not keep and elem in _FORMATS:
            stream.seek(count * struct.calcsize("<" + _FORMATS[elem]), 1)
            return None
        values = [_value(stream, elem, keep=keep) for _ in range(count)]
        return values if keep else None
    if kind not in _FORMATS:
        raise ValueError(f"unsupported GGUF metadata type {kind}")
    return _unpack(stream, _FORMATS[kind])[0]


def read_q2_directory(path: Path, *, layers=48, experts=512, hidden=2560, intermediate=640):
    """Validate every expert shape/type/bound and return absolute tensor offsets."""
    metadata, directory = {}, {}
    with path.open("rb") as stream:
        magic, version, tensors, values = _unpack(stream, "IIQQ")
        if magic != 0x46554747 or version != 3 or tensors > 100_000 or values > 100_000:
            raise ValueError("invalid GGUF v3 header")
        for _ in range(values):
            key = _string(stream)
            value = _value(stream, keep=not key.startswith("tokenizer."))
            if not key.startswith("tokenizer."):
                metadata[key] = value
        for _ in range(tensors):
            name = _string(stream)
            dims, = _unpack(stream, "I")
            if not 1 <= dims <= 4:
                raise ValueError("invalid GGUF tensor rank")
            shape = _unpack(stream, "Q" * dims)
            kind, offset = _unpack(stream, "IQ")
            if name in directory:
                raise ValueError(f"duplicate GGUF tensor {name}")
            directory[name] = (shape, kind, offset)
        alignment = int(metadata.get("general.alignment", 32))
        if alignment <= 0 or alignment & (alignment - 1):
            raise ValueError("invalid GGUF alignment")
        data_start = (stream.tell() + alignment - 1) // alignment * alignment
    required = {"general.architecture": "qwen4exp", "qwen4exp.block_count": layers,
                "qwen4exp.expert_count": experts, "qwen4exp.embedding_length": hidden,
                "qwen4exp.expert_feed_forward_length": intermediate}
    for key, expected in required.items():
        if metadata.get(key) != expected:
            raise ValueError(f"Q2_0 geometry mismatch: {key}={metadata.get(key)!r}, expected {expected!r}")
    selected, spans = {}, []
    source_size = path.stat().st_size
    for layer in range(layers):
        for role in ("gate", "up", "down"):
            name = f"blk.{layer}.ffn_{role}_exps.weight"
            expected = (intermediate, hidden, experts) if role == "down" else (hidden, intermediate, experts)
            shape, kind, offset = directory.get(name, (None, None, None))
            if shape != expected or kind != 42:
                raise ValueError(f"missing or incompatible Q2_0 expert tensor {name}: {shape}, type {kind}")
            size = math.prod(shape) // 64 * 18
            start = data_start + offset
            if start < data_start or start + size > source_size or offset % alignment:
                raise ValueError(f"out-of-bounds or misaligned expert tensor {name}")
            selected[layer, role] = (start, size)
            spans.append((start, start + size))
    spans.sort()
    if any(a[1] > b[0] for a, b in zip(spans, spans[1:])):
        raise ValueError("overlapping GGUF expert tensors")
    actual = {name for name in directory if re.fullmatch(r"blk\.\d+\.ffn_(gate|up|down)_exps\.weight", name)}
    if len(actual) != layers * 3:
        raise ValueError("unexpected routed-expert tensor count")
    return selected


def iter_q2_expert_pieces(model_path, config, *, chunk=8 << 20):
    source = config.expert_source
    if not isinstance(source, dict) or source.get("format") != "q2_0":
        raise ValueError("Q2_0 requires an explicit expert source")
    path = Path(source["path"])
    if not path.is_absolute():
        path = Path(model_path) / path
    stat = path.stat()
    if (source.get("sha256") != SOURCE_SHA256 or stat.st_size != SOURCE_SIZE
            or source.get("verified_mtime_ns") != stat.st_mtime_ns):
        raise ValueError("Q2_0 source identity changed; reverify the complete artifact")
    directory = read_q2_directory(path, layers=config.num_layers, experts=config.num_experts,
                                  hidden=config.hidden_size, intermediate=config.moe_intermediate_size)
    E, H, I = config.num_experts, config.hidden_size, config.moe_intermediate_size
    per_expert = 3 * H * I // 64 * 18
    count = max(1, min(E, chunk // per_expert))
    # 有界缓冲区读取原生量化字节，所有 48x512 专家完整加载，禁止缺失专家别名。
    with path.open("rb", buffering=0) as stream:
        for layer in range(config.num_layers):
            for e0 in range(0, E, count):
                e1 = min(E, e0 + count)
                pieces = {}
                for role in ("gate", "up", "down"):
                    rows, width = (H, I // 64 * 18) if role == "down" else (I, H // 64 * 18)
                    piece = torch.empty((e1 - e0, rows, width), dtype=torch.uint8)
                    dst = memoryview(piece.numpy()).cast("B")
                    start, total = directory[layer, role]
                    stream.seek(start + e0 * (total // E))
                    done = 0
                    while done < len(dst):
                        got = stream.readinto(dst[done:])
                        if not got:
                            raise ValueError("short Q2_0 expert read")
                        done += got
                    pieces[role] = piece
                yield layer, e0, e1, pieces
