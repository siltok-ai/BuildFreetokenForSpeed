"""Freeze the reproduced final-window abort fix as a new immutable candidate."""
from pathlib import Path
import difflib
import gzip
import hashlib
import json
import subprocess
import sys

ROOT=Path(__file__).resolve().parent
DEV=ROOT/'mtp-engine-development-v1'
SOURCE=DEV/'build-source'
REPO=Path('C:/workspace/worktrees/build-freetoken-flash-next-strata-q2-mtp')
sys.path.insert(0,str(REPO/'tools'))
from prepare_source import prepare,apply_patch,sha256


def main():
    old=json.loads((DEV/'final-abort-gate-v1.json').read_text(encoding='utf-8'))
    fixed=json.loads((DEV/'final-abort-gate-v2.json').read_text(encoding='utf-8'))
    tests=json.loads((DEV/'final-components-v1.json').read_text(encoding='utf-8'))
    if old['status']!='failed' or fixed['status']!='passed' or tests['status']!='passed':
        raise RuntimeError('Fail-before/pass-after abort evidence is missing')
    base='7b5e0b54f23e9542333b0d24bf0075c72ef1bef7'
    head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=SOURCE,text=True).strip()
    if subprocess.check_output(['git','status','--porcelain','--untracked-files=no'],cwd=SOURCE):
        raise RuntimeError('Commit the reviewed source before freezing')
    patch=REPO/'patches/series/strataq2mtp2-0019-final-window-cancel.patch'
    version_patch=REPO/'patches/series/strataq2mtp2-0020-package-version.patch'
    series_path=REPO/'patches/strataq2mtp2-series.json'
    profile_path=REPO/'build/profiles/strataq2mtp2.json'
    for p in (patch,version_patch,series_path,profile_path):
        if p.exists():
            raise FileExistsError(p)
    files=subprocess.check_output(['git','diff','--name-only',base,head,'--','python','tests'],cwd=SOURCE,text=True).splitlines()
    expected={'python/freetoken/scheduler/scheduler.py','tests/scheduler/test_abort_inflight_prefill.py'}
    if set(files)!=expected:
        raise RuntimeError('Unexpected final-abort source inventory')
    patch.write_bytes(subprocess.check_output(['git','diff','--binary',base,head,'--','python','tests'],cwd=SOURCE))
    replay,_=prepare(REPO/'build/profiles/strataq2mtp1.json',ROOT/'mtp2-final-abort-replay-v1')
    before={name:sha256(replay/name) for name in files}
    apply_patch(replay,patch,ROOT/'mtp2-final-abort-replay-v1/logs/final-abort.log')
    hashes={name:sha256(replay/name) for name in files}
    if hashes!={name:sha256(SOURCE/name) for name in files} or any(tests['source_sha256'][name]!=hashes[name] for name in files):
        raise RuntimeError('Final-abort patch differs from tested source')
    version_name='python/freetoken/version.py'
    left=(replay/version_name).read_text(encoding='utf-8')
    right=left.replace('0.1.3+speed.strataq2mtp1','0.1.3+speed.strataq2mtp2')
    if left==right:
        raise RuntimeError('Unexpected predecessor version')
    text='diff --git a/'+version_name+' b/'+version_name+'\n'+''.join(difflib.unified_diff(
        left.splitlines(keepends=True),right.splitlines(keepends=True),fromfile='a/'+version_name,tofile='b/'+version_name))
    version_patch.write_bytes(text.replace('\n','\r\n').encode())
    series=json.loads((REPO/'patches/strataq2mtp1-series.json').read_text(encoding='utf-8'))
    series['patches'].append(dict(id='FTMTP-006',path=patch.relative_to(REPO).as_posix(),sha256=sha256(patch),
        kind='correctness',status='active',title='Cancel final in-flight windows removed from the decode queue',
        upstream_status='Local scheduler ownership fix; no official contribution',files=files))
    series['patches'].append(dict(id='FTMTP-007',path=version_patch.relative_to(REPO).as_posix(),sha256=sha256(version_patch),
        kind='packaging',status='active',title='Independent final-abort-fix version',upstream_status='Speed-specific identity',files=[version_name]))
    series_path.write_text(json.dumps(series,indent=2)+'\n',encoding='utf-8')
    profile=json.loads((REPO/'build/profiles/strataq2mtp1.json').read_text(encoding='utf-8'))
    profile['input_sha256'].pop(profile['patch_series'])
    profile.update(custom_version='0.1.3+speed.strataq2mtp2',wheel_filename='freetoken-0.1.3+speed.strataq2mtp2-cp312-cp312-win_amd64.whl',patch_series=series_path.relative_to(REPO).as_posix())
    for p in (patch,version_patch,series_path):
        profile['input_sha256'][p.relative_to(REPO).as_posix()]=sha256(p)
    profile_path.write_text(json.dumps(profile,indent=2)+'\n',encoding='utf-8')
    output=REPO/'research/mtp/evidence/final-abort-20261014-v1'
    output.mkdir(exist_ok=False)
    evidence=[]
    for name in ('probe_final_abort_gate_v1.py','probe_final_abort_gate_v2.py','final-abort-gate-v1.json',
        'final-abort-gate-v1.log','final-abort-gate-v2.json','final-abort-gate-v2.log',
        'run_final_components_v1.py','final-components-v1.json','final-components-v1.log'):
        raw=(DEV/name).read_bytes()
        p=output/(name+'.gz')
        p.write_bytes(gzip.compress(raw,mtime=0))
        evidence.append(dict(path=p.relative_to(REPO).as_posix(),sha256=sha256(p),raw_sha256=hashlib.sha256(raw).hexdigest()))
    summary=dict(status='final_window_abort_regression_fail_before_pass_after',source_revision=head,source_base_commit=base,
        predecessor='research/mtp/evidence/installed-ownership-20261014-v1/index.json',
        predecessor_sha256=sha256(REPO/'research/mtp/evidence/installed-ownership-20261014-v1/index.json'),
        base_profile='build/profiles/strataq2mtp1.json',profile=profile_path.relative_to(REPO).as_posix(),profile_sha256=sha256(profile_path),
        patch=patch.relative_to(REPO).as_posix(),patch_sha256=sha256(patch),baseline_sha256=before,replayed_source_sha256=hashes,
        component_tests='84 passed, 12 subtests passed',evidence=evidence,
        scope='Real CPU Req/DecodeManager/HybridRadix ownership and callback paths; no full GPU final-window cancellation acceptance',
        speed_mtp_acceptance=False,performance_acceptance=False,full_engine_acceptance=False)
    (output/'index.json').write_text(json.dumps(summary,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(dict(status=summary['status'],profile_sha256=summary['profile_sha256'],source_revision=head)))


if __name__=='__main__':
    main()
