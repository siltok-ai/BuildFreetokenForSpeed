"""Run established components using the independently installed MTP wheel."""
from pathlib import Path

ROOT = Path(__file__).resolve().parent
base = ROOT/'run_prefix_tests_v1.py'
source = base.read_text(encoding='utf-8').replace('prefix-tests-v1.json','installed-components-v1.json')
source = source.replace("SOURCE = ROOT / 'build-source'", "SOURCE = ROOT.parent / 'mtp1-derived-materials-v1/candidate-source/build-source'")
source = source.replace("sys.path.insert(0, str(SOURCE / 'python'))", "# Use installed FreeToken Python; only the test files come from replayed source.")
source = source.replace('source_override=True','source_override=False')
source = source.replace("    'tests/models/qwen4_exp/test_gguf_gdn.py',", "    'tests/models/qwen4_exp/test_gguf_gdn.py',\n    'tests/models/qwen4_exp/test_mtp_runtime.py',\n    'tests/scheduler/test_abort_inflight_prefill.py',\n    'tests/scheduler/test_scheduler_status.py',\n    'tests/scheduler/test_req_append_host.py',")
source = source.replace('import pytest', "assert freetoken.__version__ == '0.1.3+speed.strataq2mtp1'\nassert 'site-packages' in freetoken.__file__\nimport pytest")
exec(compile(source,str(base),'exec'),{'__file__':str(base),'__name__':'__main__'})
