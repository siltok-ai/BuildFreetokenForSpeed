"""Copy the new candidate materials and preserve installed ownership evidence."""
from pathlib import Path
import gzip
import hashlib
import json
import shutil

ROOT = Path(__file__).resolve().parent
REPO = Path('C:/workspace/worktrees/build-freetoken-flash-next-strata-q2-mtp')
MATERIALS = ROOT/'mtp1-derived-materials-v1'
TARGET = REPO/'artifacts/strataq2mtp1-cp312-cu130-sm120'
EVIDENCE = REPO/'research/mtp/evidence/installed-ownership-20261014-v1'


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    if TARGET.exists() or EVIDENCE.exists():
        raise FileExistsError('Candidate output must be independent')
    actual = json.loads((ROOT/'mtp1-installed-ownership-v1.json').read_text(encoding='utf-8'))
    if actual['status'] != 'passed' or actual['source_override'] is not False:
        raise RuntimeError('Installed ownership gates did not pass')
    TARGET.mkdir()
    for name in ('wheels','kernel-cache'):
        shutil.copytree(MATERIALS/name,TARGET/name)
    shutil.copy2(MATERIALS/'build-record.json',TARGET/'build-record.json')
    EVIDENCE.mkdir()
    names = ['probe_mtp1_installed_ownership_v1.py','mtp1-installed-ownership-v1.json',
        'mtp1-installed-ownership-v1-resource.json','mtp1-installed-ownership-v1-resource.log',
        'mtp1-installed-ownership-v1-resource.stdout.log','mtp1-installed-ownership-v1-resource.stderr.log',
        'freeze_mtp_profile_v1.py','mtp1-derived-materials-v1.log',
        'mtp1-environment-base-freeze-v1.txt', 'mtp1-environment-dependencies-v1.txt',
        'mtp1-environment-dependencies-v2.txt',
        *[f'mtp1-environment-install-v{i}.log' for i in (1,2,3)]]
    archives=[]
    for name in names:
        raw=(ROOT/name).read_bytes()
        out=EVIDENCE/(name+'.gz')
        out.write_bytes(gzip.compress(raw,mtime=0))
        archives.append(dict(path=out.relative_to(REPO).as_posix(),sha256=sha(out),raw_sha256=hashlib.sha256(raw).hexdigest()))
    record=json.loads((TARGET/'build-record.json').read_text(encoding='utf-8'))
    package=Path(actual['package'])
    native={name:sha(package.parent/name) for name in record['native_modules']}
    if native != record['binary_reuse']['native_sha256']:
        raise RuntimeError('Installed native bytes differ from the frozen base')
    mtp=Path('C:/workspace/models/Qwen/Qwen3.8-Flash-Next/de4b8e4d43b917e7706784d8bb445c9af86a3540/mtp-freetoken-q2-v1/runtime.json')
    summary=dict(status='installed_mtp_candidate_ownership_verified',profile='build/profiles/strataq2mtp1.json',
        profile_sha256=sha(REPO/'build/profiles/strataq2mtp1.json'),materials=TARGET.relative_to(REPO).as_posix(),
        build_record_sha256=sha(TARGET/'build-record.json'),version=actual['version'],
        wheel_sha256=record['wheel_sha256'],installed_native_sha256=native,
        source_override=False,installed_ownership_verified=True,model_mtp_runtime_manifest_sha256=sha(mtp),
        predecessor='research/mtp/evidence/engine-lifecycle-20261014-v1/index.json',
        predecessor_sha256=sha(REPO/'research/mtp/evidence/engine-lifecycle-20261014-v1/index.json'),
        profile_created=True,wheel_created=True,speed_mtp_acceptance=False,performance_acceptance=False,
        full_engine_acceptance=False,evidence=archives,ownership_checks=actual['checks'],
        pending=['installed length/cancel/quality and longer-output performance',
                 'failure-path and actual Speed worker/backend/HTTP on/off', 'old-model/package regressions'])
    (EVIDENCE/'index.json').write_text(json.dumps(summary,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(dict(status=summary['status'],wheel_sha256=summary['wheel_sha256'])))


if __name__=='__main__':
    main()
