"""无效模型实验：仅用于验证资源与执行流程，生成内容不代表原模型。"""

import os


def retained_expert_layers(num_layers: int) -> int:
    """显式双开关启用专家层别名；默认始终加载完整模型。"""
    raw = os.environ.get("FREETOKEN_INVALID_EXPERT_KEEP_LAYERS")
    if raw is None:
        return num_layers
    if os.environ.get("FREETOKEN_ALLOW_INVALID_MODEL") != "1":
        raise RuntimeError("expert alias experiment requires FREETOKEN_ALLOW_INVALID_MODEL=1; outputs are invalid")
    count = int(raw)
    if not 1 <= count <= num_layers:
        raise ValueError("invalid retained expert layer count")
    return count
