"""Long-output correctness with CPU phase timings; separate from release throughput acceptance."""
from pathlib import Path
import sys
import time

ROOT = Path(__file__).resolve().parent
base = ROOT / 'probe_integrated_mtp_v1.py'
source = base.read_text(encoding='utf-8').replace("integrated-mtp-v1.json", "integrated-mtp-v2.json")
source = source.replace('max_tokens=64', 'max_tokens=512').replace("['token_ids'][:64]", "['token_ids'][:512]")
source = source.replace("('70-1', 'short-1-cold')", "('70-1', 'short-1-cold'), ('diverse-4096-0', 'diverse4096-0-cold')")
source = source.replace("    save()\n    prompts =", "    install_timing(llm, report)\n    save()\n    prompts =")
source = source.replace("        llm.cache_manager.check_integrity()", "        report['runs'][-1]['cpu_phase_ms'] = dict(timings)\n        timings.clear()\n        llm.cache_manager.check_integrity()")

timings = {}


def install_timing(llm, report):
    runtime = llm.engine.mtp_runtime
    report['cpu_timing_diagnostic'] = True
    for owner, name in [(runtime, '_ensure_owner'), (runtime, 'before_native'), (runtime, 'after_native'),
                         (runtime, '_replay'), (runtime.draft, 'prime'), (runtime.draft_graphs, 'chain'),
                         (runtime.draft_graphs, 'prime')]:
        original = getattr(owner, name)
        key = type(owner).__name__ + '.' + name
        def timed(*args, _original=original, _key=key, **kwargs):
            start = time.perf_counter()
            try:
                return _original(*args, **kwargs)
            finally:
                timings.setdefault(_key, []).append((time.perf_counter() - start) * 1000)
        setattr(owner, name, timed)


namespace = {'__file__': str(base), '__name__': '__main__', 'install_timing': install_timing, 'timings': timings}
exec(compile(source, str(base), 'exec'), namespace)
