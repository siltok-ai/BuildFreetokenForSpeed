"""Extend the existing native drain rather than introducing another finish protocol."""
from pathlib import Path

path = Path(__file__).resolve().parent / 'build-source/python/freetoken/scheduler/scheduler.py'
code = path.read_text(encoding='utf-8')
old = '''                    self.decode_manager.remove_req(req)
                    self._free_req_resources(req)
                    new_finished_reqs.add(req)
                    continue
                if req in self.finished_reqs:'''
new = '''                    if batch.mtp_token_ids is not None:
                        req.append_host(batch.mtp_token_ids)
                    self.decode_manager.remove_req(req)
                    self._free_req_resources(req)
                    new_finished_reqs.add(req)
                    continue
                if req in self.finished_reqs:'''
if old not in code:
    raise RuntimeError('Native abort drain changed')
code = code.replace(old, new, 1)
start = code.index('                next_token = next_tokens_cpu[i]\n')
end = code.index('\n        self.finished_reqs = new_finished_reqs', start)
body = code[start:end].replace('                next_token = next_tokens_cpu[i]\n', '', 1)
body = body.replace('                    new_finished_reqs.add(req)\n',
                    '                    new_finished_reqs.add(req)\n                    break\n', 1)
indented = '\n'.join('    ' + line if line else line for line in body.split('\n'))
lead = '''                output_tokens = (batch.mtp_token_ids if batch.mtp_token_ids is not None
                                 else next_tokens_cpu[i:i + 1])
                for next_token in output_tokens:
'''
code = code[:start] + lead + indented + code[end:]
code = code.replace('        self.finished_reqs = new_finished_reqs\n',
    '        self.finished_reqs = new_finished_reqs\n        if batch.mtp_token_ids is not None:\n            batch.mtp_delivered_count = len(reply)\n', 1)
path.write_bytes(code.replace('\n', '\r\n').encode('utf-8'))
