"""Promote validated private helpers into the development source, without installed-file edits."""
import ast
from pathlib import Path
import re

ROOT = Path(__file__).resolve().parent
RESEARCH = Path('C:/workspace/worktrees/build-freetoken-flash-next-strata-q2-mtp/research/mtp')
DEST = ROOT / 'build-source/python/freetoken/models/qwen4_exp'

DOCS = {
    '__init__': 'Own compressed draft weights/KV; borrow target embedding, head and RoPE.',
    'initial_residual': 'Normalize all four streams before shared per-stream fc_hidden projection.',
    'mix': 'Use the validated FP32 HC path with merged BF16 down/inject projection.',
    'key_value': 'Write cell-position K/V to the private draft cache.',
    'prime': 'Build only K/V from verified target residuals and next tokens.',
    'step': 'Cell p pairs R_p with token p+1 and predicts p+2; recursive KV remains private.',
    'attend': 'Mask future/private speculative cells on device before paged FP32 attention.',
    'chain': 'Launch one draft chain and read its candidates once on the host.',
    'close': 'Destroy owned graphs after their users drain; borrowed target weights stay owned by the model.',
}


class EnglishDocs(ast.NodeTransformer):
    def visit_FunctionDef(self, node):
        self.generic_visit(node)
        if node.body and isinstance(node.body[0], ast.Expr) and isinstance(node.body[0].value, ast.Constant):
            node.body[0].value.value = DOCS.get(node.name, 'Use owned draft state with verified inputs.')
        return node


for old, new in [('drafter.py', 'mtp_drafter.py'), ('draft_graph.py', 'mtp_draft_graph.py')]:
    path = DEST / new
    if path.exists():
        raise FileExistsError(path)
    code = ast.unparse(EnglishDocs().visit(ast.parse((RESEARCH / old).read_text(encoding='utf-8')))) + '\n'
    if old == 'draft_graph.py':
        begin = code.index('        globals_copy = ')
        end = code.index('        key_before = ', begin)
        code = code[:begin] + code[end:]
        code = code.replace('self.attention(q.reshape', 'qsa_sparse_paged_attention(q.reshape')
        code = code.replace('indices, self.table, self.mapping).reshape', 'indices, self.table, self.mapping, num_stages=1).reshape')
        code = re.sub(r'class _StageOneKernel:.*?\nclass DraftGraphs:', 'class DraftGraphs:', code, flags=re.S)
        code = code.replace('import types\n', '')
    code = code.replace('Calibration prototype', 'MTP draft')
    if not code.isascii():
        raise ValueError('Promoted source comments/docstrings must be ASCII')
    path.write_bytes(code.replace('\n', '\r\n').encode('utf-8'))
