"""Actual full-weight generation through the new native scheduler MTP branch."""
import hashlib
import json
from pathlib import Path
import sys
import time

ROOT = Path(__file__).resolve().parent
OUT = ROOT / 'integrated-mtp-v1.json'
if OUT.exists():
    raise FileExistsError(OUT)
sys.path.insert(0, str(ROOT.parent))
import capture_freetoken_reference
SOURCE = ROOT / 'build-source'
sys.path.insert(0, str(SOURCE / 'python'))
import torch
import freetoken.kernel
freetoken.kernel.__path__.append(str(Path(sys.executable).parent.parent / 'Lib/site-packages/freetoken/kernel'))
import freetoken.kernel.backend as backend
backend.is_flashinfer_installed = lambda: False
from freetoken.core import SamplingParams
from freetoken.llm.llm import LLM
from freetoken.message import DetokenizeMsg
from freetoken.mm.config import MultimodalConfig, ENCODER_KINDS


class ObservedLLM(LLM):
    def __init__(self, *args, **kwargs):
        self.arrivals = []
        self.prefills = []
        super().__init__(*args, **kwargs)

    def offline_send_result(self, messages):
        at = time.perf_counter()
        self.arrivals.extend((at, m.next_token, m.finished, m.finish_reason)
                             for m in messages if isinstance(m, DetokenizeMsg))
        super().offline_send_result(messages)

    def _forward(self, data):
        if data.batch.is_prefill:
            self.prefills.append([dict(cached_len=r.cached_len, device_len=r.device_len) for r in data.batch.reqs])
        return super()._forward(data)


def main():
    report = dict(status='running', scope='Development-source full-weight native scheduler MTP; no Speed or release acceptance',
                  source_override=True, protected_experts=7168, cache_slots=9216, runs=[],
                  source_sha256={p.relative_to(SOURCE).as_posix(): hashlib.sha256(p.read_bytes()).hexdigest()
                                 for p in (SOURCE / 'python').rglob('*.py')})
    def save():
        OUT.write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding='utf-8')
    save()
    start = time.perf_counter()
    llm = ObservedLLM(str(ROOT.parent / 'gguf-checkpoint'), dtype=torch.bfloat16, max_running_req=1,
        attention_backend='qsa_sparse', moe_strategy='offload', ple_backend='disk', expert_load='serial',
        mm=MultimodalConfig(disabled_encoders=frozenset(ENCODER_KINDS)),
        moe_q2_resident_experts=7168, moe_q2_dynamic_slots=1024, moe_cache_size=9216,
        moe_cache_auto=False, kv_reserve_tokens=8192, num_token_override=8192, cuda_graph_max_bs=1,
        memory_ratio=.9, max_seq_len_override=262144, max_extend_tokens=4096, cache_type='radix', decode_log_interval=1000,
        mtp_runtime_path='C:/workspace/models/Qwen/Qwen3.8-Flash-Next/de4b8e4d43b917e7706784d8bb445c9af86a3540/mtp-freetoken-q2-v1')
    report['load_seconds'] = time.perf_counter() - start
    save()
    prompts = json.loads((ROOT.parent / 'prompts.json').read_text(encoding='utf-8'))
    baseline = json.loads((ROOT.parent / 'dev7-native-performance-11264-v1.json').read_text(encoding='utf-8'))
    for key, label in [('70-0', 'short-0-cold'), ('70-0', 'short-0-hot'), ('70-1', 'short-1-cold')]:
        llm.arrivals.clear()
        llm.prefills.clear()
        before_rounds = len(llm.engine.mtp_runtime.rounds)
        start = time.perf_counter()
        output = llm.generate([prompts[key]['ids']], SamplingParams(temperature=0, max_tokens=64))[0]
        torch.cuda.synchronize()
        records = llm.arrivals
        gold = next(r for r in baseline['runs'] if r['label'] == label)['output']['token_ids'][:64]
        equal = output['token_ids'] == gold
        report['runs'].append(dict(label=label, prompt_tokens=len(prompts[key]['ids']), output=output,
            actual_output_tokens=len(output['token_ids']), output_matches_baseline=equal,
            ttft_seconds=records[0][0] - start, actual_decode_tps=(len(records)-1)/(records[-1][0]-records[0][0]),
            finish_reason=records[-1][3], prefills=llm.prefills.copy(),
            rounds=llm.engine.mtp_runtime.rounds[before_rounds:],
            arrival_offsets=[r[0]-records[0][0] for r in records]))
        llm.cache_manager.check_integrity()
        save()
        if not equal:
            raise RuntimeError('Integrated MTP output differs from baseline: ' + label)
    llm.shutdown()
    report['status'] = 'passed'
    save()
    print(json.dumps(dict(status=report['status'], runs=len(report['runs']))))


if __name__ == '__main__':
    main()
