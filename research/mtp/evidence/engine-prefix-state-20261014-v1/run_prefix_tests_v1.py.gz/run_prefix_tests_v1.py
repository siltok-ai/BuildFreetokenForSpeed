"""Verify owned MTP prefix/slot state using development source and unchanged dev7 native binaries."""
import hashlib
import json
import os
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parent
OUT = ROOT / 'prefix-tests-v1.json'
if OUT.exists():
    raise FileExistsError(OUT)
sys.path.insert(0, str(ROOT.parent))
import capture_freetoken_reference
SOURCE = ROOT / 'build-source'
sys.path.insert(0, str(SOURCE / 'python'))
import freetoken
import freetoken.kernel
import freetoken.kernel.backend as backend
backend.is_flashinfer_installed = lambda: False
native = Path(sys.executable).parent.parent / 'Lib/site-packages/freetoken/kernel'
freetoken.kernel.__path__.append(str(native))
import pytest

tests = [
    'tests/kvcache/test_mtp_pool.py', 'tests/kvcache/test_qsa_pool.py',
    'tests/kvcache/test_linear_state_pool_alloc.py', 'tests/scheduler/test_hybrid_cache_manager.py',
    'tests/scheduler/test_cache_rebuild.py', 'tests/models/qwen4_exp/test_gguf_ple.py',
    'tests/models/qwen4_exp/test_gguf_gdn.py',
]
os.chdir(SOURCE)
paths = [p for p in (SOURCE / 'python').rglob('*.py')] + [SOURCE / p for p in tests]
hashes = {p.relative_to(SOURCE).as_posix(): hashlib.sha256(p.read_bytes()).hexdigest() for p in paths}
code = pytest.main(['-q', '-ra', *tests])
after = {p.relative_to(SOURCE).as_posix(): hashlib.sha256(p.read_bytes()).hexdigest() for p in paths}
if after != hashes:
    raise RuntimeError('Development source changed during component tests')
OUT.write_text(json.dumps(dict(status='passed' if code == 0 else 'failed', exit_code=int(code),
    scope='MTP prefix, residual, reserved-slot, allocation and CUDA window components; no full-model or service MTP acceptance',
    source_override=True, source_version=freetoken.__version__, native_binaries_from=str(native),
    source_sha256=hashes), indent=2), encoding='utf-8')
raise SystemExit(int(code))
