"""Inspect the real GGUF configuration and MTP resource geometry without loading model weights."""
import json
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parent
OUT = ROOT / 'real-gguf-mtp-config-v1.json'
if OUT.exists():
    raise FileExistsError(OUT)
sys.path.insert(0, str(ROOT.parent))
import capture_freetoken_reference
sys.path.insert(0, str(ROOT / 'build-source/python'))
import torch
import freetoken.kernel
freetoken.kernel.__path__.append(str(Path(sys.executable).parent.parent / 'Lib/site-packages/freetoken/kernel'))
import freetoken.kernel.backend as backend
backend.is_flashinfer_installed = lambda: False
from freetoken.distributed import DistributedInfo
from freetoken.engine.engine import _adjust_config
from freetoken.kvcache.qsa_pool import QSAKVCache
from freetoken.kvcache.linear_state_pool import _linear_pool_num_slots, _linear_pool_min_slots, state_pool_bytes
from freetoken.mm.config import MultimodalConfig, ENCODER_KINDS
from freetoken.models.qwen4_exp.mtp_state import MTP_LAST_RESIDUAL
from freetoken.scheduler.config import SchedulerConfig

options = dict(model_path=str(ROOT.parent / 'gguf-checkpoint'), tp_info=DistributedInfo(0, 1),
    dtype=torch.bfloat16, max_running_req=1, attention_backend='qsa_sparse', moe_strategy='offload',
    mm=MultimodalConfig(disabled_encoders=frozenset(ENCODER_KINDS)),
    moe_q2_resident_experts=7680, moe_q2_dynamic_slots=1024, moe_cache_size=9728,
    num_token_override=8192, max_seq_len_override=262144, max_extend_tokens=4096, cache_type='radix')
runtime = 'C:/workspace/models/Qwen/Qwen3.8-Flash-Next/de4b8e4d43b917e7706784d8bb445c9af86a3540/mtp-freetoken-q2-v1'
records = []
for enabled in (False, True):
    config = SchedulerConfig(**options, mtp_runtime_path=runtime if enabled else None)
    _adjust_config(config)
    model = config.model_config
    records.append(dict(mtp_state_enabled=enabled, cache_type=config.cache_type,
        hidden_size=model.hidden_size, hc_count=model.qwen4_args.hc_count,
        capture_rows=model.mtp_capture_rows, state_slots=_linear_pool_num_slots(config),
        min_state_slots=_linear_pool_min_slots(config), state_pool_bytes=state_pool_bytes(config),
        kv_cost=QSAKVCache.kv_cost(config),
        slot_states=[dict(name=s.name, shape=s.shape, dtype=str(s.dtype)) for s in model.slot_states]))
    assert config.cache_type == 'hybrid_radix'
    assert any(s.name == MTP_LAST_RESIDUAL for s in model.slot_states) == enabled
assert records[1]['state_slots'] == records[0]['state_slots'] + 4
OUT.write_text(json.dumps(dict(status='passed', scope='Real fixed GGUF configuration and declared resource geometry; model weights and MTP driver not loaded',
    source_override=True, runs=records), indent=2), encoding='utf-8')
print(json.dumps(records))
