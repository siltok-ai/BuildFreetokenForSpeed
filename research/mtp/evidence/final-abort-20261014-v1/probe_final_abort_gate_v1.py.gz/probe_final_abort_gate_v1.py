"""Replay the real CPU ownership managers at the final-window cancellation boundary."""
from pathlib import Path

ROOT=Path(__file__).resolve().parent
base=ROOT/'run_prefix_tests_v1.py'
source=base.read_text(encoding='utf-8').replace('prefix-tests-v1.json','final-abort-gate-v1.json')
begin=source.index('tests = [')
end=source.index('os.chdir(SOURCE)',begin)
source=source[:begin]+"tests = ['tests/scheduler/test_abort_inflight_prefill.py']\n"+source[end:]
source=source.replace("['-q', '-ra', *tests]","['-q', '-ra', '-k', 'final_mtp_bundle', *tests]")
exec(compile(source,str(base),'exec'),{'__file__':str(base),'__name__':'__main__'})
