"""Run the full component suite with the reproduced final-window abort regression."""
from pathlib import Path

ROOT=Path(__file__).resolve().parent
base=ROOT/'run_lifecycle_components_v1.py'
source=base.read_text(encoding='utf-8').replace('lifecycle-components-v1.json','final-components-v1.json')
exec(compile(source,str(base),'exec'),{'__file__':str(base),'__name__':'__main__'})
