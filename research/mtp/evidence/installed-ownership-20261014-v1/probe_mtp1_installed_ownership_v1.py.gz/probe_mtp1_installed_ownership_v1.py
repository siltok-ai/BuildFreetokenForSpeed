"""Installed MTP wheel: real retained-prefix eviction and page-boundary anchor state."""
from pathlib import Path
import hashlib
import json
import sys
import time

ROOT = Path(__file__).resolve().parent
import capture_freetoken_reference
import torch
import freetoken
import freetoken.kernel.backend as backend
backend.is_flashinfer_installed = lambda: False
from freetoken.core import SamplingParams
from freetoken.llm.llm import LLM
from freetoken.message import DetokenizeMsg
from freetoken.mm.config import MultimodalConfig, ENCODER_KINDS

OUT = ROOT/'mtp1-installed-ownership-v1.json'
if OUT.exists():
    raise FileExistsError(OUT)
if freetoken.__version__ != '0.1.3+speed.strataq2mtp1' or 'site-packages' not in freetoken.__file__:
    raise RuntimeError('This gate must use the independent installed wheel')


class ObservedLLM(LLM):
    def __init__(self, *args, **kwargs):
        self.deliveries = []
        self.prefills = []
        super().__init__(*args, **kwargs)

    def offline_send_result(self, messages):
        self.deliveries.extend(dict(token=m.next_token, finished=m.finished, finish_reason=m.finish_reason)
            for m in messages if isinstance(m, DetokenizeMsg))
        super().offline_send_result(messages)

    def _forward(self, data):
        if data.batch.is_prefill:
            self.prefills.append([r.cached_len for r in data.batch.reqs])
        return super()._forward(data)


def main():
    package = Path(freetoken.__file__).parent
    report = dict(status='running', source_override=False, package=str(package), version=freetoken.__version__,
        package_python_sha256={p.relative_to(package).as_posix():hashlib.sha256(p.read_bytes()).hexdigest()
            for p in package.rglob('*.py')}, runs=[], checks=[],
        scope='Installed wheel ownership/eviction/anchor gate; short outputs, not a performance benchmark or Speed acceptance')
    def save():
        OUT.write_text(json.dumps(report, ensure_ascii=False, indent=2),encoding='utf-8')
    save()
    llm = ObservedLLM(str(ROOT/'gguf-checkpoint'), dtype=torch.bfloat16, max_running_req=1,
        attention_backend='qsa_sparse', moe_strategy='offload', ple_backend='disk', expert_load='serial',
        mm=MultimodalConfig(disabled_encoders=frozenset(ENCODER_KINDS)),
        moe_q2_resident_experts=7168, moe_q2_dynamic_slots=1024, moe_cache_size=9216,
        moe_cache_auto=False, kv_reserve_tokens=8192, num_token_override=8192, cuda_graph_max_bs=1,
        memory_ratio=.9, max_seq_len_override=262144, max_extend_tokens=4096, cache_type='radix', decode_log_interval=1000,
        mtp_runtime_path='C:/workspace/models/Qwen/Qwen3.8-Flash-Next/de4b8e4d43b917e7706784d8bb445c9af86a3540/mtp-freetoken-q2-v1')
    runtime = llm.engine.mtp_runtime
    eligible = runtime.eligible
    prompts = json.loads((ROOT/'prompts.json').read_text(encoding='utf-8'))

    def clear():
        llm.cache_manager.rebuild(llm.engine.num_pages, llm.engine.page_table)
        llm.cache_manager.check_integrity()

    def run(label, ids, native=False, cold=True):
        if cold:
            clear()
        runtime.eligible = (lambda batch: False) if native else eligible
        runtime.rounds.clear()
        llm.deliveries.clear()
        llm.prefills.clear()
        started = time.perf_counter()
        output = llm.generate([ids], SamplingParams(max_tokens=17,ignore_eos=True))[0]
        torch.cuda.synchronize()
        llm.cache_manager.check_integrity()
        entry = dict(label=label, output=output, deliveries=llm.deliveries.copy(), prefills=llm.prefills.copy(),
            rounds=list(runtime.rounds), native_target_only=native, seconds=time.perf_counter()-started,
            available_pages=llm.cache_manager.available_size//llm.config.page_size,
            free_pages=len(llm.cache_manager.free_slots),
            evictable_state_slots=llm.cache_manager.prefix_cache.mamba_evictable_size)
        assert len(entry['deliveries']) == 17 and entry['deliveries'][-1]['finish_reason'] == 'length'
        report['runs'].append(entry)
        save()
        return entry

    ids = prompts['70-0']['ids'][:63]
    gold = run('anchor-token-reference',ids,native=True)
    anchor_id = gold['deliveries'][0]['token']
    llm.toolcall_anchor_id = anchor_id
    snapshots = {}
    for label, native in [('anchor-native',True),('anchor-mtp',False)]:
        actual = run(label,ids,native=native)
        assert actual['deliveries'] == gold['deliveries']
        key = torch.tensor([*ids,anchor_id],dtype=torch.int32)
        match = llm.cache_manager.prefix_cache.match_prefix(key)
        assert match.cached_len == 64 and match.mamba_value is not None
        pool = llm.engine.linear_state_pool
        slot = match.mamba_value
        state = dict(conv=pool.conv_states[:,slot].cpu(), recurrent=pool.recurrent_states[:,slot].cpu())
        state.update({name:value[:,slot].cpu() for name,value in pool.slot_states.items()})
        snapshots[label] = state
    comparisons = {name:bool(torch.equal(snapshots['anchor-native'][name],snapshots['anchor-mtp'][name]))
        for name in snapshots['anchor-native']}
    assert all(comparisons.values()), comparisons
    report['checks'].append(dict(label='page-boundary-anchor', token_id=anchor_id, prefix_tokens=64,
        state_exact_equal=comparisons, synthetic_anchor_token=True))
    del snapshots
    llm.toolcall_anchor_id = None
    fork = [*ids,anchor_id,13]
    gold = run('anchor-fork-native',fork,native=True,cold=False)
    actual = run('anchor-fork-mtp',fork,cold=False)
    assert actual['prefills'][0][0] == 64
    assert gold['deliveries'] == actual['deliveries']
    report['checks'].append(dict(label='anchor-fork-reuse', matched=True))
    save()

    llm.rebuild_cache(num_pages=16)
    llm.prefill_budget = 4096
    prefix_keys = []
    for i in range(8):
        ids = prompts['70-0']['ids']+[13+i]*350
        entry = run('retained-pressure-'+str(i),ids,cold=False)
        key = torch.tensor(ids[:384],dtype=torch.int32)
        match = llm.cache_manager.prefix_cache.match_prefix(key)
        assert match.cached_len == 384 and match.mamba_value is not None
        prefix_keys.append(key)
        entry['own_retained_prefix'] = match.cached_len
        save()
    old_match = llm.cache_manager.prefix_cache.match_prefix(prefix_keys[0])
    assert old_match.cached_len < 384
    assert any(r['evictable_state_slots'] >= 2 for r in report['runs'] if r['label'].startswith('retained-pressure'))
    report['checks'].append(dict(label='real-retained-prefix-eviction', pool_pages=16, page_size=64,
        submitted_requests=8, retained_prefix_before_pressure=384, oldest_prefix_after_pressure=old_match.cached_len,
        each_request_delivered_tokens=17, ignore_eos=True))
    llm.cache_manager.check_integrity()
    llm.shutdown()
    assert not runtime.graphs and runtime.draft_graphs is None
    report['status']='passed'
    save()
    print(json.dumps(dict(status=report['status'],checks=len(report['checks']),runs=len(report['runs']))))


if __name__=='__main__':
    main()
