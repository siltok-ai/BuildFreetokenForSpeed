"""Create an independent candidate MTP profile after basic engine lifecycle gates."""
from pathlib import Path
import difflib
import hashlib
import json

REPO = Path('C:/workspace/worktrees/build-freetoken-flash-next-strata-q2-mtp')
SOURCE = Path('C:/workspace/artifacts/flash-next-strata-q2-20261012/mtp-engine-development-v1/build-source')


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    version = '0.1.3+speed.strataq2mtp1'
    profile_path = REPO/'build/profiles/strataq2mtp1.json'
    series_path = REPO/'patches/strataq2mtp1-series.json'
    version_patch = REPO/'patches/series/strataq2mtp1-0018-package-version.patch'
    for p in (profile_path, series_path, version_patch):
        if p.exists():
            raise FileExistsError(p)
    checkpoints = [json.loads((REPO/'research/mtp/evidence'/d/'index.json').read_text(encoding='utf-8'))
        for d in ('engine-foundation-20261014-v1', 'engine-prefix-state-20261014-v1',
                  'engine-scheduler-20261014-v1', 'engine-lifecycle-20261014-v1')]
    if checkpoints[-1]['basic_scheduler_lifecycle_verified'] is not True:
        raise RuntimeError('Basic lifecycle evidence is missing')
    name = 'python/freetoken/version.py'
    old = (SOURCE/name).read_text(encoding='utf-8')
    new = old.replace('0.1.3+speed.strataq2dev7', version)
    if old == new:
        raise RuntimeError('Unexpected source version')
    text = f'diff --git a/{name} b/{name}\n'+''.join(difflib.unified_diff(
        old.splitlines(keepends=True), new.splitlines(keepends=True), fromfile='a/'+name, tofile='b/'+name))
    version_patch.write_bytes(text.replace('\n','\r\n').encode())
    series = json.loads((REPO/'patches/strataq2dev7-series.json').read_text(encoding='utf-8'))
    titles = ['Native causal verification and row state transactions',
              'Owned auxiliary prefix KV, last residual and reserved transaction budget',
              'Greedy MTP draft/verify/catchup graphs and native scheduler delivery',
              'Bounded diagnostics and page-capacity-constrained lookahead']
    for number, row, title in zip(range(14,18), checkpoints, titles):
        patch = REPO/row['patch']
        if sha(patch) != row['patch_sha256']:
            raise RuntimeError('Checkpoint patch identity differs')
        series['patches'].append(dict(id=f'FTMTP-{number-13:03d}', path=row['patch'], sha256=sha(patch),
            kind='feature', status='active', title=title,
            upstream_status='local optional FreeToken integration; pinned MIT Strata references; no official contribution',
            files=sorted(row['replayed_source_sha256'])))
    series['patches'].append(dict(id='FTMTP-005', path=version_patch.relative_to(REPO).as_posix(),
        sha256=sha(version_patch), kind='packaging', status='active', title='Independent optional MTP version',
        upstream_status='Speed-specific material identity', files=[name]))
    series_path.write_text(json.dumps(series, indent=2)+'\n',encoding='utf-8')
    profile = json.loads((REPO/'build/profiles/strataq2dev7.json').read_text(encoding='utf-8'))
    profile['input_sha256'].pop(profile['patch_series'])
    profile.update(custom_version=version, wheel_filename=f'freetoken-{version}-cp312-cp312-win_amd64.whl',
        patch_series=series_path.relative_to(REPO).as_posix())
    for p in [*(REPO/row['patch'] for row in checkpoints), version_patch, series_path]:
        profile['input_sha256'][p.relative_to(REPO).as_posix()] = sha(p)
    profile_path.write_text(json.dumps(profile, indent=2)+'\n',encoding='utf-8')
    print(json.dumps(dict(status='candidate_profile_requires_installed_speed_validation',
        profile=str(profile_path), profile_sha256=sha(profile_path), version=version, native_inputs_changed=False)))


if __name__ == '__main__':
    main()
