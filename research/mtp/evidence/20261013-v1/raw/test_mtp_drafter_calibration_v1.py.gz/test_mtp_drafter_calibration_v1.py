"""Measure real FreeToken-kernel MTP draft acceptance; target delivery remains non-speculative."""
import json
from pathlib import Path
import sys
import time

ROOT=Path(__file__).resolve().parent
OUT=ROOT/'mtp-drafter-calibration-v1.json'
if OUT.exists(): raise FileExistsError(OUT)
sys.path.insert(0,'C:/workspace/worktrees/build-freetoken-flash-next-strata-q2-mtp/research/mtp')
import capture_freetoken_reference
import torch
import freetoken
import freetoken.kernel.backend as backend
backend.is_flashinfer_installed=lambda:False
from freetoken.models.qwen4_exp.hc import GatedResidual
from freetoken.core import SamplingParams
from freetoken.llm.llm import LLM
from freetoken.mm.config import MultimodalConfig,ENCODER_KINDS
from drafter import MtpDrafter


def main():
    """在当前安装引擎的真实R上运行独立预测层，不把诊断时序当成MTP交付速度。"""
    assert freetoken.__version__=='0.1.3+speed.strataq2dev7'
    report=dict(status='running',scope='Diagnostic FreeToken-kernel draft acceptance with oracle target catch-up. No speculative delivery or MTP throughput claim.',
        version=freetoken.__version__,protected_experts=8064,total_cache_slots=10112,chains=[])
    def save(): OUT.write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
    save()
    original_mix=GatedResidual.mix
    def capture_mix(self,residual):
        if not self.use_combine:
            if not hasattr(self,'_mtp_residual_capture'):
                self._mtp_residual_capture=torch.empty((4096,10240),device=residual.device,dtype=torch.float32)
            self._mtp_residual_capture[:len(residual)].copy_(residual)
        return original_mix(self,residual)
    GatedResidual.mix=capture_mix
    llm=LLM(str(ROOT/'gguf-checkpoint'),dtype=torch.bfloat16,max_running_req=1,
        attention_backend='qsa_sparse',moe_strategy='offload',ple_backend='disk',expert_load='serial',
        mm=MultimodalConfig(disabled_encoders=frozenset(ENCODER_KINDS)),
        moe_q2_resident_experts=8064,moe_q2_dynamic_slots=1024,moe_cache_size=10112,
        moe_cache_auto=False,kv_reserve_tokens=8192,num_token_override=8192,cuda_graph_max_bs=1,
        memory_ratio=.9,max_seq_len_override=262144,max_extend_tokens=4096,cache_type='radix',decode_log_interval=1000)
    engine=llm.engine
    draft=MtpDrafter(Path('C:/workspace/models/Qwen/Qwen3.8-Flash-Next/de4b8e4d43b917e7706784d8bb445c9af86a3540/mtp-freetoken-q2-v1'),engine.model)
    report['drafter_owned_bytes']=draft.owned_bytes
    report['main_residual_capture_bytes']=4096*10240*4
    raw_capture=engine.model.model.hyper_connection_mixer._mtp_residual_capture
    original_forward=engine.forward_batch
    prime_done=False
    output_index=0
    def forward(batch,args):
        nonlocal prime_done,output_index
        req=batch.reqs[0]
        base=req.cached_len
        count=req.extend_len
        result=original_forward(batch,args)
        result.copy_done_event.synchronize()
        if not prime_done:
            if base!=0 or count!=70: raise RuntimeError('Calibration prompt geometry changed')
            before=time.perf_counter()
            draft.prime(raw_capture[:count-1],batch.input_ids[1:count])
            torch.cuda.synchronize()
            report['draft_prompt_prime_ms']=1000*(time.perf_counter()-before)
            prime_done=True
        cell=base+count-1
        residual=raw_capture[count-1:count].clone()
        token=result.next_tokens_gpu[0].reshape(1)
        candidates=[]
        started=time.perf_counter()
        for step in range(3):
            token,residual=draft.step(residual,token,cell+step)
            candidates.append(int(token.item()))
        row=dict(target_output_index=output_index,cell=cell,drafts=candidates,
            diagnostic_eager_chain_ms=1000*(time.perf_counter()-started))
        report['chains'].append(row)
        output_index+=1
        save()
        print(json.dumps(row),flush=True)
        return result
    engine.forward_batch=forward
    prompt=json.loads((ROOT/'prompts.json').read_text(encoding='utf-8'))['70-0']
    output=llm.generate([prompt['ids']],SamplingParams(temperature=0,top_p=1,max_tokens=32))[0]
    reference=json.loads((ROOT/'dev7-native-performance-11264-v1.json').read_text(encoding='utf-8'))['runs'][0]['output']['token_ids'][:32]
    assert output['token_ids']==reference
    for row in report['chains']:
        start=row['target_output_index']+1
        gold=output['token_ids'][start:start+3]
        row['target_next_ids']=gold
        accepted=0
        for actual,want in zip(row['drafts'],gold):
            if actual!=want: break
            accepted+=1
        row['accepted_prefix']=accepted
    complete=[r for r in report['chains'] if len(r['target_next_ids'])==3]
    report.update(status='measured',original_target_output_unchanged=True,output=output,
        full_three_step_windows=len(complete),
        conditional_prefix_acceptance=[sum(r['accepted_prefix']>=k for r in complete)/len(complete) for k in (1,2,3)])
    save()
    llm.shutdown()
    print(json.dumps({k:v for k,v in report.items() if k not in {'chains','output'}},ensure_ascii=False))


if __name__=='__main__':
    with torch.inference_mode(): main()
