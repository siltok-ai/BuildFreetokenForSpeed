"""Exercise development source with verified dev7 native binaries, without installation edits."""
import hashlib
import json
import os
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parent
OUT = ROOT / 'foundation-tests-v1.json'
if OUT.exists():
    raise FileExistsError(OUT)
sys.path.insert(0, str(ROOT.parent))
import capture_freetoken_reference
SOURCE = ROOT / 'build-source'
sys.path.insert(0, str(SOURCE / 'python'))
import freetoken
import freetoken.kernel
import freetoken.kernel.backend as backend
backend.is_flashinfer_installed = lambda: False
native_dir = Path(sys.executable).parent.parent / 'Lib/site-packages/freetoken/kernel'
freetoken.kernel.__path__.append(str(native_dir))
import pytest

tests = [
    'tests/scheduler/test_hybrid_cache_manager.py',
    'tests/scheduler/test_cache_rebuild.py',
    'tests/models/qwen4_exp/test_gguf_ple.py',
    'tests/models/qwen4_exp/test_gguf_gdn.py',
]
os.chdir(SOURCE)
code = pytest.main(['-q', '-ra', *tests])
changed = [
    'python/freetoken/core.py', 'python/freetoken/attention/linear.py',
    'python/freetoken/attention/qsa_sparse.py', 'python/freetoken/scheduler/cache.py',
    'python/freetoken/models/qwen4_exp/gdn.py', 'python/freetoken/models/qwen4_exp/ple.py',
    *tests,
]
report = dict(status='passed' if code == 0 else 'failed', exit_code=int(code),
              scope='Development source component tests; not full MTP engine or Speed acceptance',
              source=str(SOURCE), runtime_version=freetoken.__version__,
              source_override=True, native_binaries_from=str(native_dir),
              sha256={p: hashlib.sha256((SOURCE / p).read_bytes()).hexdigest() for p in changed})
OUT.write_text(json.dumps(report, indent=2), encoding='utf-8')
raise SystemExit(int(code))
