"""Exercise newly prepared weights through installed Speed discovery/backend."""
from pathlib import Path
import os,json,time,psutil
import freetoken,silitok_speed
from silitok_speed.manifest_schema import load,check_disk
from silitok_speed.discovery import _register_chat
from silitok_speed.config import get_config
BASE=Path(__file__).resolve().parents[1]
OUT=Path(__file__).with_name('installed-delivery-runtime-v2.json')
CACHE=Path(r'C:\workspace\worktrees\build-freetoken-flash-next-strata-q2-mtp\artifacts\strataq2mtp2-cp312-cu130-sm120\kernel-cache')
assert not OUT.exists()
report=dict(status='running',freetoken_version=freetoken.__version__,speed_version=silitok_speed.__version__,freetoken_file=freetoken.__file__,speed_file=silitok_speed.__file__,kernel_cache=str(CACHE),triton_cache=os.environ['TRITON_CACHE_DIR'],runs=[],worker_pids=[],scope='New prepared/relocated data via installed Python backend and actual discovery registration; not HTTP/compiled application/installer')
assert 'site-packages' in freetoken.__file__ and 'site-packages' in silitok_speed.__file__
assert freetoken.__version__=='0.1.3+speed.strataq2mtp2'
def save(): OUT.write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
class Capture:
 def register_model(self,spec,cls,config): self.spec=spec;self.cls=cls;self.config=config
def main():
 for mode,root in [('on',BASE/'delivery-relocated-v1/models'),('off',BASE/'delivery-preparation-v1/models')]:
  manifest=load(root/'manifest.json'); skips=check_disk(manifest,root);assert skips=={},skips
  os.environ['SILITOK_CONFIG']=str(root/'speed-config');get_config.cache_clear();resource=get_config().resource
  assert resource.gpu_probe=='nvml' and resource.vram_safety_gb==.0625 and resource.commit_safety_gb==2
  entry=manifest.models[0];capture=Capture()
  _register_chat(capture,entry.id,entry.artifacts,entry.engine,None,False,str(root))
  capture.config.extra['kernel_cache_dir']=str(CACHE)
  capture.config.extra['startup_timeout_seconds']=600
  backend=capture.cls();row=dict(mode=mode,root=str(root),resource=dict(gpu_probe=resource.gpu_probe,vram_safety_gb=resource.vram_safety_gb,commit_safety_gb=resource.commit_safety_gb),extra=capture.config.extra,runs=[]);report['runs'].append(row);save()
  try:
   backend.load(capture.spec,capture.config);report['worker_pids'].append(backend.worker_pid)
   row['geometry']=backend.cache_geometry();row['mtp_identity']=backend.mtp_identity();save()
   query=dict(messages=[dict(role='user',content='What is 17 times 31? Reply with only the integer.')],enable_thinking=False)
   eos=list(backend.generate(query,max_new_tokens=32,temperature=0,top_p=1))[-1];row['eos']=eos;save()
   assert eos['text'].strip()=='527' and eos['finish_reason']=='stop'
   prompt=json.loads((BASE/'prompts.json').read_text(encoding='utf-8'))['70-0']['text']
   gold=json.loads((BASE/'speed-mtp2-http-performance-v4.json').read_text(encoding='utf-8'))['runs']
   for repeat in range(2):
    arrivals=[];ids=[];final=None;start=time.perf_counter()
    for event in backend.generate(dict(messages=[dict(role='user',content=prompt)],enable_thinking=False),max_new_tokens=512,temperature=0,top_p=1):
     if event['type']=='token':arrivals.append(time.perf_counter());ids.append(event['token_id'])
     if event['type']=='final':final=event
    result=dict(repeat=repeat,final=final,token_ids=ids,ttft_ms=1000*(arrivals[0]-start),decode_tps=511/(arrivals[-1]-arrivals[0]),matches_frozen_text=final['text']==next(g for g in gold if g['label']=='70-0-'+str(repeat))['text'])
    row['runs'].append(result);save()
    assert len(ids)==512 and final['tokens']==ids and final['finish_reason']=='length' and result['matches_frozen_text']
   row['passed']=True
  finally:
   backend.unload();row['worker_gone']=not psutil.pid_exists(report['worker_pids'][-1]) if report['worker_pids'] else True;save()
  assert row['worker_gone']
 report['status']='passed';save();print(json.dumps(dict(status='passed',modes=len(report['runs']),workers_gone=all(r['worker_gone'] for r in report['runs']))))
if __name__=='__main__':main()
