from pathlib import Path
p=Path(__file__).resolve().parent
s=(p/'test_mtp_target_window_v5_late_position.py').read_text(encoding='utf-8')
s=s.replace("OUT = ROOT/'mtp-target-window-v5-late-position.json'","OUT = ROOT/'mtp-target-window-v6-moving-late.json'")
s=s.replace('import capture_freetoken_reference','import sys\nsys.path.insert(0,"C:/workspace/worktrees/build-freetoken-flash-next-strata-q2-mtp/research/mtp")\nfrom target_window import TargetWindow\nimport capture_freetoken_reference')
s=s.replace('    tested=set()','    tested=set()\n    moving=None')
s=s.replace('        max_error=float((logits-sequential).abs().max())','''        max_error=float((logits-sequential).abs().max())
        restore(refs,initial)
        moving_picks=moving.replay(req.input_ids[:base].tolist(),ids[:4],base).cpu().tolist()
        moving_errors=compare(refs,states[3])
        moving_layer_errors=(refs['recurrent']-states[3]['recurrent']).abs().flatten(1).max(1).values.tolist()
        restore(refs,states[3])''')
s=s.replace('            all_rows_argmax_equal=True, logits_max_abs_error=max_error,','''            moving_picks=moving_picks,moving_expected=ids[1:5],moving_errors=moving_errors,
            moving_recurrent_layer_errors=moving_layer_errors,
            all_rows_argmax_equal=True, logits_max_abs_error=max_error,''')
s=s.replace('    def forward(batch,args):\n','''    def forward(batch,args):
        nonlocal moving
        if batch.is_decode and moving is None:
            refs=state_refs(batch.reqs[0]); initial=clone(refs)
            moving=TargetWindow(engine,batch.reqs[0],batch.reqs[0].cached_len)
            restore(refs,initial)
''')
s=s.replace('    llm.shutdown()','    moving.close()\n    llm.shutdown()')
out=p/'test_mtp_target_window_v6_moving_late.py'
if out.exists(): raise FileExistsError(out)
out.write_text(s,encoding='utf-8',newline='\n')
