"""Installed FreeToken target-window feasibility; oracle inputs are not an MTP speed result."""
import copy
import json
from pathlib import Path
import time

ROOT = Path(__file__).resolve().parent
OUT = ROOT/'mtp-target-window-v6-moving-late.json'
if OUT.exists(): raise FileExistsError(OUT)
import sys
sys.path.insert(0,"C:/workspace/worktrees/build-freetoken-flash-next-strata-q2-mtp/research/mtp")
from target_window import TargetWindow
import capture_freetoken_reference
import torch
import freetoken
import freetoken.kernel.backend as backend
backend.is_flashinfer_installed=lambda:False
from freetoken.attention.linear import build_fla_metadata
from freetoken.core import Batch, SamplingParams
from freetoken.llm.llm import LLM
from freetoken.mm.config import MultimodalConfig, ENCODER_KINDS


def write(report):
    """追加独立原型结果；不覆盖已有验收资料。"""
    OUT.write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding='utf-8')


def main():
    """在实际单请求decode位置执行顺序、批量和强制拒绝，再恢复原调度器。"""
    assert freetoken.__version__ == '0.1.3+speed.strataq2dev7'
    report=dict(status='running', version=freetoken.__version__, diagnostic_static_conv_override=True,
        scope='Diagnostic eager target windows in installed FreeToken. Oracle drafts; no drafter, no MTP throughput claim.',
        protected_experts=8064, dynamic_slots=1024, total_cache_slots=10112, windows=[])
    write(report)
    llm=LLM(str(ROOT/'gguf-checkpoint'), dtype=torch.bfloat16, max_running_req=1,
        attention_backend='qsa_sparse', moe_strategy='offload', ple_backend='disk', expert_load='serial',
        mm=MultimodalConfig(disabled_encoders=frozenset(ENCODER_KINDS)),
        moe_q2_resident_experts=8064, moe_q2_dynamic_slots=1024, moe_cache_size=10112,
        moe_cache_auto=False, kv_reserve_tokens=8192, num_token_override=8192,
        cuda_graph_max_bs=1, memory_ratio=.9, max_seq_len_override=262144,
        max_extend_tokens=4096, cache_type='radix', decode_log_interval=1000)
    # Diagnostic-only override: known single-request T avoids device-to-host item() during capture.
    import freetoken.models.qwen4_exp.gdn as gdn
    from freetoken.kernel.triton.causal_conv1d_triton import causal_conv1d_varlen as static_varlen
    def graph_varlen(x,weight,states,cu,indices,initial):
        return static_varlen(x,weight,states,cu,indices,initial,
            max_seq_len=x.shape[-1],batch=cu.numel()-1)
    gdn.causal_conv1d_varlen=graph_varlen
    engine=llm.engine
    pool=engine.linear_state_pool
    kv=engine.kv_cache
    initial_forward=engine.forward_batch
    tested=set()
    moving=None

    def state_refs(req):
        """捕获会被窗口前推的GDN、conv、PLE状态及QSA跨调用ring。"""
        slot=req.linear_slot_idx if req.linear_slot_idx is not None else req.table_idx
        refs=dict(conv=pool.conv_states[:,slot], recurrent=pool.recurrent_states[:,slot],
            qsa_pending=kv._pending_ring[req.table_idx])
        refs.update({name:t[:,slot] for name,t in pool.slot_states.items()})
        return refs

    def clone(refs):
        return {name:t.clone() for name,t in refs.items()}

    def restore(refs, snapshot):
        """原地址恢复递推状态；语义缓存页按committed长度可见，后续输入会覆盖尾部。"""
        for name,t in refs.items(): t.copy_(snapshot[name])

    def compare(refs, expected):
        errors={name:float((t.float()-expected[name].float()).abs().max()) for name,t in refs.items()}
        return errors

    def window(req, base, ids, *, prepare_only=False):
        """同一请求的连续token走causal-prefill元数据，避免多request decode图共享GDN槽。"""
        r=copy.copy(req)
        r.cached_len=base
        r.device_len=base+len(ids)
        r.input_ids=torch.cat([req.input_ids[:base], torch.tensor(ids, dtype=torch.int32)])
        r.mamba_ping_pong=None  # 原型不向radix发布未验证中间状态。
        batch=Batch(reqs=[r], phase='prefill')
        batch.padded_reqs=[r]
        batch.input_ids=torch.tensor(ids, dtype=torch.int32, device=engine.device)
        batch.positions=torch.arange(base,base+len(ids),dtype=torch.int32,device=engine.device)
        batch.out_loc=engine.page_table[req.table_idx,batch.positions.long()]
        batch.fla_metadata=build_fla_metadata(batch,engine.device)
        engine.attn_backend.prepare_metadata(batch)
        if prepare_only: return batch
        with engine.ctx.forward_batch(batch),engine.model.forward_host_ctx(batch,False):
            mixed=engine.model.model.forward(batch.input_ids,batch)
            # 对每一行计算target head；普通prefill只取最后一行，不适合验证草稿。
            logits=engine.model.lm_head.quant_method.apply(engine.model.lm_head,mixed)
        return logits

    def diagnose(req, token):
        """比较实际连续四步与四行验证，并强制拒绝测试1/2/3行提交及后继输出。"""
        base=req.cached_len
        if base//engine.ctx.page_size != (base+3)//engine.ctx.page_size:
            raise RuntimeError('Prototype must remain within an already allocated KV page')
        refs=state_refs(req)
        initial=clone(refs)
        ids=[token]
        seq_logits=[]
        states=[]
        virtual_req=copy.copy(req)
        prompt_prefix=req.input_ids[:base].clone()
        for row in range(4):
            # disk PLE uses CPU token history; a virtual step must include earlier oracle rows.
            virtual_req.input_ids=torch.cat([prompt_prefix,torch.tensor(ids,dtype=torch.int32)])
            logits=window(virtual_req,base+row,[ids[row]])
            seq_logits.append(logits.detach().clone())
            ids.append(int(logits.argmax(-1).item()))
            states.append(clone(refs))
        req=virtual_req
        restore(refs,initial)
        logits=window(req,base,ids[:4])
        sequential=torch.cat(seq_logits)
        max_error=float((logits-sequential).abs().max())
        restore(refs,initial)
        moving_picks=moving.replay(req.input_ids[:base].tolist(),ids[:4],base).cpu().tolist()
        moving_errors=compare(refs,states[3])
        moving_layer_errors=(refs['recurrent']-states[3]['recurrent']).abs().flatten(1).max(1).values.tolist()
        restore(refs,states[3])
        picks=logits.argmax(-1).tolist()
        all_accepted=compare(refs,states[3])
        if picks != ids[1:5]: raise RuntimeError('Window target argmax differs from serial target')
        # 不追逐尾数；记录幅度，要求递推状态正常且PLE/ring提交一致。
        if max(all_accepted.values()) > .01: raise RuntimeError('Window state diverges materially')
        rejects=[]
        for accepted_inputs in (1,2,3):
            restore(refs,initial)
            bad=list(ids[:4])
            bad[accepted_inputs]=(bad[accepted_inputs]+1)%engine.model._config.vocab_size
            wrong=window(req,base,bad)
            rejected=wrong.argmax(-1).tolist()
            if rejected[accepted_inputs-1] != ids[accepted_inputs]:
                raise RuntimeError('Rejected suffix affected an earlier causal row')
            restore(refs,initial)
            committed=window(req,base,ids[:accepted_inputs])
            errors=compare(refs,states[accepted_inputs-1])
            continuation=window(req,base+accepted_inputs,[ids[accepted_inputs]])
            next_id=int(continuation.argmax(-1).item())
            if next_id != ids[accepted_inputs+1] or max(errors.values())>.01:
                raise RuntimeError('Partial commit/replay corrupted the continuation')
            rejects.append(dict(accepted_input_rows=accepted_inputs, committed_target_picks=committed.argmax(-1).tolist(),
                state_max_abs_error=errors, continuation_next_id=next_id))
        # 热身后的同输入对照，包含host PLE stage和元数据成本，不含人为拒绝实验。
        times=[]
        for count in (1,2,3,4):
            samples=[]
            for _ in range(3):
                restore(refs,initial)
                torch.cuda.synchronize()
                started=time.perf_counter()
                window(req,base,ids[:count])
                torch.cuda.synchronize()
                samples.append(1000*(time.perf_counter()-started))
            times.append(dict(input_rows=count,eager_target_window_ms=samples))
        graph_times=[]
        ple=engine.model._ple_table
        for count in (1,2,3,4):
            restore(refs,initial)
            batch=window(req,base,ids[:count],prepare_only=True)
            # Eager warmup initializes backend scratch before capture; preserve only static graph nodes.
            for _ in range(2):
                restore(refs,initial)
                with engine.ctx.forward_batch(batch),engine.model.forward_host_ctx(batch,False):
                    mixed=engine.model.model.forward(batch.input_ids,batch)
                    engine.model.lm_head.quant_method.apply(engine.model.lm_head,mixed)
            torch.cuda.synchronize()
            restore(refs,initial)
            graph=torch.cuda.CUDAGraph()
            with torch.cuda.graph(graph,stream=engine.stream):
                with engine.ctx.forward_batch(batch):
                    mixed=engine.model.model.forward(batch.input_ids,batch)
                    graph_logits=engine.model.lm_head.quant_method.apply(engine.model.lm_head,mixed)
            samples=[]
            context=ple._ple_context(req.input_ids,base)
            run=torch.tensor([*context,*ids[:count]],dtype=torch.int64)
            for _ in range(5):
                restore(refs,initial)
                torch.cuda.synchronize()
                started=time.perf_counter()
                # Captured PLE lookup reads the graph buffer and WAIT flag, even for multi-token causal metadata.
                ple.fill([run],graph=True)
                graph.replay()
                ple._graph_consumed.record(engine.stream)
                torch.cuda.synchronize()
                samples.append(1000*(time.perf_counter()-started))
            error=float((graph_logits-sequential[:count]).abs().max())
            picks=graph_logits.argmax(-1).tolist()
            state_error=compare(refs,states[count-1])
            if picks!=ids[1:count+1] or max(state_error.values())>.01:
                raise RuntimeError('Captured causal window diverged')
            graph_times.append(dict(input_rows=count,graph_target_window_ms=samples,
                logits_max_abs_error=error,state_max_abs_error=state_error))
            graph.reset()
        restore(refs,initial)
        torch.cuda.synchronize()
        row=dict(base_position=base, input_ids=ids[:4], target_ids=ids[1:5],
            moving_picks=moving_picks,moving_expected=ids[1:5],moving_errors=moving_errors,
            moving_recurrent_layer_errors=moving_layer_errors,
            all_rows_argmax_equal=True, logits_max_abs_error=max_error,
            all_accepted_state_max_abs_error=all_accepted, forced_rejections=rejects,
            state_snapshot_bytes=sum(t.numel()*t.element_size() for t in initial.values()),
            timings=times, fixed_position_graph_timings=graph_times)
        report['windows'].append(row)
        write(report)
        print(json.dumps(row,ensure_ascii=False),flush=True)

    def forward(batch,args):
        nonlocal moving
        if batch.is_decode and moving is None:
            refs=state_refs(batch.reqs[0]); initial=clone(refs)
            moving=TargetWindow(engine,batch.reqs[0],batch.reqs[0].cached_len)
            restore(refs,initial)
        if batch.is_decode and len(tested)<2 and batch.reqs[0].cached_len>=174:
            req=batch.reqs[0]
            if req.cached_len%engine.ctx.page_size <= engine.ctx.page_size-4:
                # 两个位置覆盖QSA group非对齐及对齐的实际状态。
                residue=req.cached_len%4
                if residue in (0,2) and residue not in tested:
                    tested.add(residue)
                    diagnose(req,int(batch.input_ids[0].item()))
        return initial_forward(batch,args)

    engine.forward_batch=forward
    prompt=json.loads((ROOT/'prompts.json').read_text(encoding='utf-8'))['70-0']
    output=llm.generate([prompt['ids']],SamplingParams(temperature=0,top_p=1,max_tokens=128))[0]
    reference=json.loads((ROOT/'dev7-native-performance-11264-v1.json').read_text(encoding='utf-8'))['runs'][0]['output']['token_ids'][:128]
    assert output['token_ids']==reference
    assert tested=={0,2}
    report.update(status='passed', original_generation_unchanged=True, output=output,
        note='Target oracle windows establish feasibility only. Actual draft chain, moving-position graph staging, IPC and MTP budget are still pending.')
    write(report)
    moving.close()
    llm.shutdown()


if __name__=='__main__':
    with torch.inference_mode(): main()
