"""Supervise one owned model job with commit and CUDA-context-free GPU memory samples."""
import ctypes
import supervise


class MemoryInfo(ctypes.Structure):
    _fields_ = [(name, ctypes.c_ulonglong) for name in ('total', 'free', 'used')]


class NvmlMemory(supervise.Nvml):
    def sample(self):
        result = super().sample()
        memory = MemoryInfo()
        status = self.lib.nvmlDeviceGetMemoryInfo(self.handle, ctypes.byref(memory))
        if status != 0:
            raise RuntimeError('NVML GPU memory sample failed')
        result.update(gpu_total_bytes=memory.total, gpu_used_bytes=memory.used, gpu_free_bytes=memory.free)
        return result


supervise.Nvml = NvmlMemory
if __name__ == '__main__':
    raise SystemExit(supervise.main())
