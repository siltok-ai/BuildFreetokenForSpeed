"""Native-state audit and actual 512-token cold speculative measurements, one owned model."""
import json
from pathlib import Path
import statistics
import sys
import time

ROOT=Path(__file__).resolve().parent
OUT=ROOT/'mtp-speculative-matrix-v2-noaudit.json'
if OUT.exists(): raise FileExistsError(OUT)
sys.path.insert(0,'C:/workspace/worktrees/build-freetoken-flash-next-strata-q2-mtp/research/mtp')
import capture_freetoken_reference
import torch
import freetoken
import freetoken.kernel.backend as backend
backend.is_flashinfer_installed=lambda:False
from freetoken.models.qwen4_exp.hc import GatedResidual
from freetoken.core import SamplingParams
from freetoken.llm.llm import LLM
from freetoken.mm.config import MultimodalConfig,ENCODER_KINDS
from drafter import MtpDrafter
import speculative_loop
from target_window import TargetWindow
from window_audit import AuditedWindow


def main():
    """每组清空prefix/动态LRU，统计真实候选验证后的交付，保持dev7正式环境字节不变。"""
    assert freetoken.__version__=='0.1.3+speed.strataq2dev7'
    report=dict(status='running',scope='Isolated cold single-request greedy MTP; graph setup/prime separately recorded. No Speed or production MTP acceptance.',
        version=freetoken.__version__,protected_experts=8064,total_cache_slots=10112,
        direct_row_snapshots=True,decode_conv=True,decode_ple=True,draft_graphs=True,
        scalar_projections=False,runs=[],mtp_engine_integrated=False,speed_acceptance=False)
    def save(): OUT.write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8',newline='\n')
    save()
    original_mix=GatedResidual.mix
    def capture_mix(self,residual):
        if not self.use_combine:
            if not hasattr(self,'_mtp_residual_capture'):
                self._mtp_residual_capture=torch.empty((4096,10240),device=residual.device,dtype=torch.float32)
            self._mtp_residual_capture[:len(residual)].copy_(residual)
        return original_mix(self,residual)
    GatedResidual.mix=capture_mix
    llm=LLM(str(ROOT/'gguf-checkpoint'),dtype=torch.bfloat16,max_running_req=1,
        attention_backend='qsa_sparse',moe_strategy='offload',ple_backend='disk',expert_load='serial',
        mm=MultimodalConfig(disabled_encoders=frozenset(ENCODER_KINDS)),
        moe_q2_resident_experts=8064,moe_q2_dynamic_slots=1024,moe_cache_size=10112,
        moe_cache_auto=False,kv_reserve_tokens=8192,num_token_override=8192,cuda_graph_max_bs=1,
        memory_ratio=.9,max_seq_len_override=262144,max_extend_tokens=4096,cache_type='radix',decode_log_interval=1000)
    engine=llm.engine
    draft=MtpDrafter(Path('C:/workspace/models/Qwen/Qwen3.8-Flash-Next/de4b8e4d43b917e7706784d8bb445c9af86a3540/mtp-freetoken-q2-v1'),engine.model)
    report.update(drafter_owned_bytes=draft.owned_bytes,main_residual_capture_bytes=4096*10240*4)
    raw_capture=engine.model.model.hyper_connection_mixer._mtp_residual_capture
    original_forward=engine.forward_batch
    prompts=json.loads((ROOT/'prompts.json').read_text(encoding='utf-8'))
    baseline=json.loads((ROOT/'dev7-native-performance-11264-v1.json').read_text(encoding='utf-8'))
    baselines={r['label']:r for r in baseline['runs']}
    active={}
    def forward(batch,args):
        req=batch.reqs[0]
        if batch.is_decode and not active['tested']:
            active['tested']=True
            speculative_loop.TargetWindow=AuditedWindow if active['audit'] else TargetWindow
            try:
                result=speculative_loop.run_speculative(engine,llm.cache_manager,req,draft,
                    active['prompt']['ids'],int(batch.input_ids[0].item()),active['last_r'],
                    max_tokens=active['limit'],eos_ids=llm.eos_token_ids,
                    direct_snapshots=True,decode_conv=True,decode_ple=True,draft_graphs=True)
            finally:
                speculative_loop.TargetWindow=TargetWindow
            gold=active['baseline']['output']['token_ids'][:active['limit']]
            result['all_target_output_ids_equal']=result['output_ids']==gold
            result.update(prompt_key=active['key'],input_tokens=len(active['prompt']['ids']),
                baseline_label=active['baseline']['label'],baseline_tps=active['baseline']['decode_tps'])
            result['round_time_medians_ms']={k:statistics.median(r[k] for r in result['rounds'])
                for k in ('draft_ms','verify_ms','commit_and_catchup_ms')}
            if active['audit']: report['native_state_audit']=result
            else: report['runs'].append(result)
            save()
            if not result['all_target_output_ids_equal']:
                raise RuntimeError('Actual speculative output differs: '+active['key'])
        base=req.cached_len
        count=req.extend_len
        output=original_forward(batch,args)
        if not active['primed']:
            output.copy_done_event.synchronize()
            if base!=0 or count!=len(active['prompt']['ids']):
                raise RuntimeError('Cold prompt was chunked or reused unexpectedly')
            active['last_r']=raw_capture[count-1:count].clone()
            before=time.perf_counter()
            draft.prime(raw_capture[:count-1],batch.input_ids[1:count])
            torch.cuda.synchronize()
            active['prime_ms']=1000*(time.perf_counter()-before)
            active['primed']=True
        return output
    engine.forward_batch=forward
    AuditedWindow.output=ROOT/'mtp-window-native-audit-v3-ple.json'
    AuditedWindow.records=[]
    try:
        cases=[]
        cases += [(f'70-{i}',f'short-{i}-cold',512,False) for i in range(3)]
        cases += [('diverse-4096-0','diverse4096-0-cold',512,False)]
        for key,label,limit,audit in cases:
            engine.moe_offload_cache.reset()
            llm.cache_manager.rebuild(llm.cache_manager.num_pages,llm.cache_manager.page_table)
            active.clear()
            active.update(key=key,prompt=prompts[key],baseline=baselines[label],limit=limit,
                audit=audit,tested=False,primed=False,last_r=None)
            output=llm.generate([active['prompt']['ids']],SamplingParams(temperature=0,top_p=1,max_tokens=16))[0]
            if output['token_ids']!=active['baseline']['output']['token_ids'][:16] or not active['tested']:
                raise RuntimeError('Original target generation/restoration failed: '+key)
            result=report['native_state_audit'] if audit else report['runs'][-1]
            result.update(original_target_restored=True,prompt_prime_ms=active['prime_ms'])
            save()
            print(json.dumps(dict(prompt=key,audit=audit,tps=result['decode_tps'],
                tokens=result['output_tokens'],equal=result['all_target_output_ids_equal']),ensure_ascii=False),flush=True)
        report['status']='measured_and_cold_output_ids_passed'
        report['short_tps_median']=statistics.median(r['decode_tps'] for r in report['runs'] if r['input_tokens']==70)
    finally:
        llm.shutdown()
        GatedResidual.mix=original_mix
        save()


if __name__=='__main__':
    with torch.inference_mode(): main()
