"""Repeat lifecycle gates with the exact pending-token cancellation invariant."""
from pathlib import Path

ROOT = Path(__file__).resolve().parent
base = ROOT / 'probe_mtp_lifecycle_v4.py'
source = base.read_text(encoding='utf-8').replace('mtp-lifecycle-v4.json', 'mtp-lifecycle-v5.json')
source = source.replace(
    "assert len(llm.abort_records) == 1 and llm.abort_records[0]['cached_len'] > llm.abort_records[0]['cpu_length']",
    "assert len(llm.abort_records) == 1\n    ar = llm.abort_records[0]\n    assert ar['cached_len'] == ar['cpu_length'] - 1 + len(ar['bundle'])")
exec(compile(source, str(base), 'exec'), {'__file__': str(base), '__name__': '__main__'})
