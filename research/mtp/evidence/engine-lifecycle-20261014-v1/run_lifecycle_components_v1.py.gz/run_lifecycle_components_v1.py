"""Run new page-boundary gates and the established MTP component/regression suite."""
from pathlib import Path

ROOT = Path(__file__).resolve().parent
base = ROOT / 'run_prefix_tests_v1.py'
source = base.read_text(encoding='utf-8').replace('prefix-tests-v1.json', 'lifecycle-components-v1.json')
source = source.replace("    'tests/models/qwen4_exp/test_gguf_gdn.py',", "    'tests/models/qwen4_exp/test_gguf_gdn.py',\n    'tests/models/qwen4_exp/test_mtp_runtime.py',\n    'tests/scheduler/test_abort_inflight_prefill.py',\n    'tests/scheduler/test_scheduler_status.py',\n    'tests/scheduler/test_req_append_host.py',")
exec(compile(source, str(base), 'exec'), {'__file__': str(base), '__name__': '__main__'})
