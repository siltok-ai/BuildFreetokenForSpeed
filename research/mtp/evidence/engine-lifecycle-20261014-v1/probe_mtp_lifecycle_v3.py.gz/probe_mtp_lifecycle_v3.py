"""Full-weight scheduler lifecycle gates; no release or HTTP acceptance."""
from pathlib import Path
import hashlib
import json
import sys
import time

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT))
sys.path.insert(0, str(ROOT.parent))
import capture_freetoken_reference
SOURCE = ROOT / 'build-source'
sys.path.insert(0, str(SOURCE / 'python'))
import torch
import freetoken.kernel
freetoken.kernel.__path__.append(str(Path(sys.executable).parent.parent / 'Lib/site-packages/freetoken/kernel'))
import freetoken.kernel.backend as backend
backend.is_flashinfer_installed = lambda: False
from freetoken.core import SamplingParams
from freetoken.llm.llm import LLM
from freetoken.mm.config import MultimodalConfig, ENCODER_KINDS
from freetoken.message import AbortBackendMsg, ErrorReplyMsg, DetokenizeMsg
from freetoken.engine.engine import CacheRebuildRejected
from freetoken.llm.llm import RequestAllFinished
import freetoken.kernel.triton.sampling as sampling

OUT = ROOT / 'mtp-lifecycle-v3.json'
if OUT.exists():
    raise FileExistsError(OUT)


class LifecycleLLM(LLM):
    def __init__(self, *args, **kwargs):
        self.abort_next_window = False
        self.abort_records = []
        self.errors = []
        self.arrivals = []
        self.prefills = []
        super().__init__(*args, **kwargs)

    def generate(self, prompts, sampling_params):
        # Match the monotonic request identity used by the real Speed worker.
        self.pending_requests = [(ids, sampling_params, None) for ids in prompts]
        self.status_map = {}
        first_uid = self.counter
        try:
            self.run_forever()
        except RequestAllFinished:
            pass
        return [dict(text=self.tokenizer.decode(self.status_map[uid].output_ids),
                     token_ids=self.status_map[uid].output_ids)
                for uid in range(first_uid, first_uid + len(prompts))]

    def _forward(self, data):
        if data.batch.is_prefill:
            self.prefills.append([dict(cached_len=r.cached_len, device_len=r.device_len) for r in data.batch.reqs])
        return super()._forward(data)

    def offline_receive_msg(self, blocking=False):
        last = self._last_data
        if self.abort_next_window and last is not None and last[0].batch.mtp_token_ids is not None:
            last[1].copy_done.synchronize()
            req = last[0].batch.reqs[0]
            self.abort_next_window = False
            self.abort_records.append(dict(uid=req.uid, cached_len=req.cached_len,
                cpu_length=req.input_ids.numel(), bundle=last[0].batch.mtp_token_ids.tolist()))
            return [AbortBackendMsg(uid=req.uid)]
        return super().offline_receive_msg(blocking)

    def offline_send_result(self, messages):
        at = time.perf_counter()
        self.arrivals.extend((at, m.next_token, m.finished, m.finish_reason)
                             for m in messages if isinstance(m, DetokenizeMsg))
        self.errors.extend(dict(uid=m.uid, error=m.error) for m in messages if isinstance(m, ErrorReplyMsg))
        super().offline_send_result([m for m in messages if not isinstance(m, ErrorReplyMsg)])


def main():
    report = dict(status='running', scope='Actual native scheduler length/EOS/stop/cancel/prefix/rebuild gates',
        source_override=True, source_sha256={p.relative_to(SOURCE).as_posix(): hashlib.sha256(p.read_bytes()).hexdigest()
            for p in (SOURCE / 'python').rglob('*.py')}, runs=[], checks=[])
    def save():
        OUT.write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding='utf-8')
    save()
    llm = LifecycleLLM(str(ROOT.parent / 'gguf-checkpoint'), dtype=torch.bfloat16, max_running_req=1,
        attention_backend='qsa_sparse', moe_strategy='offload', ple_backend='disk', expert_load='serial',
        mm=MultimodalConfig(disabled_encoders=frozenset(ENCODER_KINDS)),
        moe_q2_resident_experts=7168, moe_q2_dynamic_slots=1024, moe_cache_size=9216,
        moe_cache_auto=False, kv_reserve_tokens=8192, num_token_override=8192, cuda_graph_max_bs=1,
        memory_ratio=.9, max_seq_len_override=262144, max_extend_tokens=4096, cache_type='radix', decode_log_interval=1000,
        mtp_runtime_path='C:/workspace/models/Qwen/Qwen3.8-Flash-Next/de4b8e4d43b917e7706784d8bb445c9af86a3540/mtp-freetoken-q2-v1')
    runtime = llm.engine.mtp_runtime
    eligible = runtime.eligible
    prompts = json.loads((ROOT.parent / 'prompts.json').read_text(encoding='utf-8'))

    def clear_prefix():
        assert not llm.prefill_manager.runnable and not llm.decode_manager.runnable
        llm.cache_manager.rebuild(llm.engine.num_pages, llm.engine.page_table)
        llm.cache_manager.check_integrity()

    def run(label, ids, sp, native=False, cold=True):
        if cold:
            clear_prefix()
        runtime.eligible = (lambda batch: False) if native else eligible
        llm.arrivals.clear()
        llm.prefills.clear()
        runtime.rounds.clear()
        sampling._UGEN.clear()
        sampling._UGEN[llm.device] = torch.Generator(device=llm.device).manual_seed(731)
        torch.manual_seed(731)
        torch.cuda.manual_seed_all(731)
        start = time.perf_counter()
        output = llm.generate([ids], sp)[0]
        torch.cuda.synchronize()
        llm.cache_manager.check_integrity()
        entry = dict(label=label, native_target_only=native, output=output,
            deliveries=[dict(token=x[1], finished=x[2], finish_reason=x[3]) for x in llm.arrivals],
            rounds=list(runtime.rounds), prefills=llm.prefills.copy(), seconds=time.perf_counter()-start)
        report['runs'].append(entry)
        save()
        return entry

    def pair(label, ids, sp, **kwargs):
        gold = run(label+'-native', ids, sp, native=True, **kwargs)
        actual = run(label+'-mtp', ids, sp, **kwargs)
        assert actual['output']['token_ids'] == gold['output']['token_ids'], label
        assert actual['deliveries'] == gold['deliveries'], label+' terminal/token metadata'
        report['checks'].append(dict(label=label, matched=True, outputs=len(actual['output']['token_ids']),
            deliveries=len(actual['deliveries']), mtp_windows=len(actual['rounds'])))
        save()
        return gold, actual

    for cap in (1, 2, 3, 4, 5, 17):
        pair('cap-'+str(cap), prompts['70-0']['ids'], SamplingParams(max_tokens=cap))
    _, full = pair('stop-source', prompts['70-0']['ids'], SamplingParams(max_tokens=32))
    stop = llm.tokenizer.decode(full['output']['token_ids'][3:8])
    assert stop
    _, stopped = pair('multi-token-stop', prompts['70-0']['ids'], SamplingParams(max_tokens=32, stop_strs=[stop]))
    assert stopped['deliveries'][-1]['finish_reason'] == 'stop'
    eos_prompt = llm.tokenizer.apply_chat_template([dict(role='user', content='只回复一个字：好')],
        tokenize=True, add_generation_prompt=True, enable_thinking=False, return_dict=False)
    _, eos = pair('actual-eos', eos_prompt, SamplingParams(max_tokens=64))
    assert eos['deliveries'][-1]['token'] in llm.eos_token_ids
    assert eos['deliveries'][-1]['finish_reason'] == 'stop'
    pair('ignore-eos', eos_prompt, SamplingParams(max_tokens=17, ignore_eos=True))
    _, sampled = pair('non-greedy-fallback', prompts['70-1']['ids'], SamplingParams(temperature=.7, top_p=.9, max_tokens=32))
    assert not sampled['rounds']

    run('prefix-prime', prompts['70-0']['ids'], SamplingParams(max_tokens=32))
    hot = run('prefix-hot', prompts['70-0']['ids'], SamplingParams(max_tokens=32), cold=False)
    assert hot['prefills'][0][0]['cached_len'] == 64
    branch = run('prefix-fork', prompts['70-0']['ids'][:64]+prompts['70-1']['ids'][64:], SamplingParams(max_tokens=32), cold=False)
    assert branch['prefills'][0][0]['cached_len'] == 64
    branch_gold = run('prefix-fork-native-cold', prompts['70-0']['ids'][:64]+prompts['70-1']['ids'][64:], SamplingParams(max_tokens=32), native=True)
    assert branch['output']['token_ids'] == branch_gold['output']['token_ids']
    report['checks'].append(dict(label='prefix-hot-fork', matched=True))

    llm.abort_next_window = True
    aborted = run('inflight-window-cancel', prompts['70-0']['ids'], SamplingParams(max_tokens=32))
    assert len(aborted['deliveries']) == 1
    assert llm.errors[-1]['error'] == 'request aborted'
    assert len(llm.abort_records) == 1 and llm.abort_records[0]['cached_len'] > llm.abort_records[0]['cpu_length']
    report['abort_records'] = llm.abort_records
    report['errors'] = llm.errors
    resumed = run('cancel-prefix-reuse', prompts['70-0']['ids'], SamplingParams(max_tokens=32), cold=False)
    assert resumed['output']['token_ids'] == full['output']['token_ids']
    report['checks'].append(dict(label='cancel-reuse', matched=True))
    save()

    original_graphs = {k:id(v[1]) for k,v in runtime.graphs.items()}
    try:
        llm.rebuild_cache(num_mamba_slots=1)
    except CacheRebuildRejected:
        pass
    else:
        raise AssertionError('Invalid state resize was not rejected')
    assert {k:id(v[1]) for k,v in runtime.graphs.items()} == original_graphs
    run('after-rejected-rebuild', prompts['70-1']['ids'], SamplingParams(max_tokens=17))
    old_slots = llm.engine.linear_state_pool.num_slots
    llm.rebuild_cache(num_pages=64, num_mamba_slots=old_slots-1)
    llm.cache_manager.check_integrity()
    pair('after-valid-rebuild', prompts['70-0']['ids'], SamplingParams(max_tokens=32))
    llm.prefill_budget = 64
    pair('chunked-prefill', prompts['70-1']['ids'], SamplingParams(max_tokens=32))
    report['checks'].append(dict(label='rebuild-and-chunked-prefill', matched=True))
    for i in range(8):
        ids = prompts['70-0']['ids'] + [13+i] * 350
        run('prefix-pressure-'+str(i), ids, SamplingParams(max_tokens=17), cold=False)
    report['checks'].append(dict(label='prefix-pressure', matched=True, iterations=8))
    llm.shutdown()
    assert not runtime.graphs and runtime.draft_graphs is None
    report['checks'].append(dict(label='shutdown', matched=True))
    report['status'] = 'passed'
    save()
    print(json.dumps(dict(status=report['status'], checks=len(report['checks']), runs=len(report['runs']))))


if __name__ == '__main__':
    main()
